﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;


namespace MDSProyecto
{


    public partial class AgendaServicio : Form
    {
        // Delegado para el evento de servicio agregado
        public delegate void ServicioAgregadoEventHandler(object sender, EventArgs e);

        // Declarar el evento ServicioAgregado en la clase AgendaServicio y hacerlo público
        public event ServicioAgregadoEventHandler ServicioAgregado;

        private string userEmail;
        private string connectionString;

        public AgendaServicio(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail;

            string servidor = "localhost";
            string bd = "pp";
            string usuario = "prueba";
            string password = "12345";
            string puerto = "1433";

            connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

            this.ClientSize = new System.Drawing.Size(pictureBox1.Width, pictureBox1.Height);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Suscribir al evento KeyPress para los TextBox que requieren valores numéricos
            PesoKg.KeyPress += TextBox_KeyPress;
            Alto.KeyPress += TextBox_KeyPress;
            Ancho.KeyPress += TextBox_KeyPress;
            ValorUni.KeyPress += TextBox_KeyPress;
            Cantidad.KeyPress += TextBox_KeyPress;

            // Asignar eventos Validating a los TextBox
            PesoKg.Validating += PesoKg_Validating;
            Ancho.Validating += Ancho_Validating;
            Largo.Validating += Largo_Validating;
            Alto.Validating += Alto_Validating;


        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números, el carácter de separador decimal (punto) y el carácter de control (teclas especiales como borrar)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',')
            {
                e.Handled = true;
            }

            // Permitir solo un separador decimal (punto o coma)
            if ((e.KeyChar == '.' || e.KeyChar == ',') && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void PesoKg_Validating(object sender, CancelEventArgs e)
        {
            if (decimal.TryParse(PesoKg.Text, out decimal peso))
            {
                if (peso < 50 || peso > 1400)
                {
                    e.Cancel = true;
                    PesoKg.Select(0, PesoKg.Text.Length);
                    errorProvider.SetError(PesoKg, "El peso debe estar entre 50 y 1400 (Kg).");
                }
                else
                {
                    errorProvider.SetError(PesoKg, "");
                }
            }
            else
            {
                e.Cancel = true;
                PesoKg.Select(0, PesoKg.Text.Length);
                errorProvider.SetError(PesoKg, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void Ancho_Validating(object sender, CancelEventArgs e)
        {
            if (decimal.TryParse(Ancho.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal ancho))
            {
                if (ancho < 0 || ancho > 214)
                {
                    e.Cancel = true;
                    Ancho.Select(0, Ancho.Text.Length);
                    errorProvider.SetError(Ancho, "El ancho debe estar entre 0 y 214.");
                }
                else
                {
                    errorProvider.SetError(Ancho, "");
                }
            }
            else
            {
                e.Cancel = true;
                Ancho.Select(0, Ancho.Text.Length);
                errorProvider.SetError(Ancho, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void Largo_Validating(object sender, CancelEventArgs e)
        {
            if (decimal.TryParse(Largo.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal largo))
            {
                if (largo < 0 || largo > 434)
                {
                    e.Cancel = true;
                    Largo.Select(0, Largo.Text.Length);
                    errorProvider.SetError(Largo, "El largo debe estar entre 0 y 434.");
                }
                else
                {
                    errorProvider.SetError(Largo, "");
                }
            }
            else
            {
                e.Cancel = true;
                Largo.Select(0, Largo.Text.Length);
                errorProvider.SetError(Largo, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void Alto_Validating(object sender, CancelEventArgs e)
        {
            if (decimal.TryParse(Alto.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal alto))
            {
                if (alto < 0 || alto > 225)
                {
                    e.Cancel = true;
                    Alto.Select(0, Alto.Text.Length);
                    errorProvider.SetError(Alto, "El alto debe estar entre 0 y 225.");
                }
                else
                {
                    errorProvider.SetError(Alto, "");
                }
            }
            else
            {
                e.Cancel = true;
                Alto.Select(0, Alto.Text.Length);
                errorProvider.SetError(Alto, "Por favor, ingresa un valor numérico válido.");
            }
        }
        private decimal CalcularVolumenTotal(decimal ancho, decimal alto, decimal largo, int cantidad)
        {
            // Convertir las dimensiones a metros (desde centímetros)
            decimal anchoMetros = ancho / 100m;
            decimal altoMetros = alto / 100m;
            decimal largoMetros = largo / 100m;

            // Calcular el volumen de un solo producto en metros cúbicos
            decimal volumenProducto = anchoMetros * altoMetros * largoMetros;

            // Calcular el volumen total ocupado por todos los productos en metros cúbicos
            decimal volumenTotalProductos = volumenProducto * cantidad;

            return volumenTotalProductos;
        }


        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los TextBox y la cantidad de productos
                string proEnviar = ProEnviar.Text;
                decimal pesoKg;
                decimal alto;
                decimal ancho;
                decimal valorUni;
                int cantidad;
                decimal largo;

                if (!decimal.TryParse(PesoKg.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out pesoKg) ||
                    !decimal.TryParse(Largo.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out largo) ||
                    !decimal.TryParse(Alto.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out alto) ||
                    !decimal.TryParse(Ancho.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out ancho) ||
                    !decimal.TryParse(ValorUni.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out valorUni) ||
                    !int.TryParse(Cantidad.Text, out cantidad))
                {
                    throw new FormatException();
                }

                // Validar que el paquete no supere el peso de envío máximo (1399 kg)
                decimal pesoTotal = pesoKg * cantidad;
                if (pesoTotal > 1399)
                {
                    MessageBox.Show("El paquete supera el peso de envío máximo (1399 Kg).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Calcular el volumen total de los productos en metros cúbicos
                decimal volumenTotalProductos = CalcularVolumenTotal(ancho, alto, largo, cantidad);

                // Verificar si el volumen total supera el límite del camión (20 m³)
                decimal espacioCamionMetrosCubicos = 20m; // Espacio de carga del camión en metros cúbicos

                if (volumenTotalProductos > espacioCamionMetrosCubicos)
                {
                    // Mostrar mensaje de error
                    MessageBox.Show("Los productos exceden el espacio de carga del camión.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Mostrar el volumen total ingresado por el cliente en metros cúbicos
                    MessageBox.Show($"El cliente ingresó un volumen total de {volumenTotalProductos} metros cúbicos de productos, lo cual excede la capacidad del camión (20 m³).", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                // Obtener la fecha y hora seleccionadas por el usuario en el DateTimePicker dateTimePickerFechaHora
                DateTime fechaHora = dateTimePickerFechaHora.Value;

                // Extraer la fecha y la hora por separado, si lo necesitas
                DateTime fecha = fechaHora.Date;
                TimeSpan hora = fechaHora.TimeOfDay;

                // Obtener el valor seleccionado del RadioButton dentro del GroupBox
                bool envioExp = radioButtonSi.Checked; // Si el RadioButton "Sí" está seleccionado, envioExp será true; de lo contrario, será false.

                // Insertar los datos en la base de datos
                string consultaInsertar = "INSERT INTO AgendaServicio (ProEnviar, PesoKg, Ancho, Alto, Largo, ValorUni, Cantidad, Fecha, Hora, EnvioExp, UsuarioEmail) " +
                                          "VALUES (@ProEnviar, @PesoKg, @Ancho, @Alto, @Largo, @ValorUni, @Cantidad, @Fecha, @Hora, @EnvioExp, @UsuarioEmail)";

                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    using (SqlCommand comandoInsertar = new SqlCommand(consultaInsertar, conexion))
                    {
                        comandoInsertar.Parameters.AddWithValue("@ProEnviar", proEnviar);
                        comandoInsertar.Parameters.AddWithValue("@PesoKg", pesoKg);
                        comandoInsertar.Parameters.AddWithValue("@Alto", alto);
                        comandoInsertar.Parameters.AddWithValue("@Ancho", ancho);
                        comandoInsertar.Parameters.AddWithValue("@Largo", largo);
                        comandoInsertar.Parameters.AddWithValue("@ValorUni", valorUni);
                        comandoInsertar.Parameters.AddWithValue("@Cantidad", cantidad);
                        comandoInsertar.Parameters.AddWithValue("@Fecha", fecha);
                        comandoInsertar.Parameters.AddWithValue("@Hora", hora);
                        comandoInsertar.Parameters.AddWithValue("@EnvioExp", envioExp);
                        comandoInsertar.Parameters.AddWithValue("@UsuarioEmail", userEmail);

                        conexion.Open();
                        comandoInsertar.ExecuteNonQuery();
                        conexion.Close();

                        MessageBox.Show("Datos guardados exitosamente.");
                        // Disparar el evento ServicioAgregado para notificar que se agregó un nuevo servicio
                        ServicioAgregado?.Invoke(this, EventArgs.Empty);
                        // Cerrar el formulario actual (AgendaServicio.cs)
                        this.Close();
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingresa valores numéricos válidos para PesoKg, Alto, Ancho, ValorUni y Cantidad.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
