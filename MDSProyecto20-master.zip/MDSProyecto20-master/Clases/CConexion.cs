﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Collections.Generic;

namespace MDSProyecto.Clases
{
    public class CConexion
    {
        SqlConnection conex = new SqlConnection();

        static string servidor = "localhost";
        static string bd = "pp";
        static string usuario = "prueba";
        static string password = "12345";
        static string puerto = "1433";

        public static string CadenaConexion
        {
            get { return "Data Source=" + servidor + "," + puerto + ";" + "Initial Catalog=" + bd + ";" + "Persist Security Info=true;User ID=" + usuario + ";Password=" + password; }
        }

        public CConexion()
        {
            EstablecerConexion();
        }

        public SqlConnection EstablecerConexion()
        {
            try
            {
                if (conex.State != ConnectionState.Closed)
                {
                    conex.Close();
                }

                conex.ConnectionString = CadenaConexion;
                conex.Open();
            }
            catch (SqlException e)
            {
                MessageBox.Show("No se logró conectar a la Base de Datos" + e.ToString());
                conex.Close();
            }

            return conex;
        }
        private static string emailUsuario;
        public static string EmailUsuario
        {
            get { return emailUsuario; }
            set { emailUsuario = value; }
        }
        public DataTable ObtenerTarjetasPorUsuario(string userEmail)
        {
            string query = "SELECT Numero, NombreTitular, Año, Mes, CVV FROM Tarjetas WHERE UsuarioEmail = @UsuarioEmail";
            DataTable tarjetas = new DataTable();

            using (SqlCommand cmd = new SqlCommand(query, conex))
            {
                cmd.Parameters.AddWithValue("@UsuarioEmail", userEmail);

                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    try
                    {
                        adapter.Fill(tarjetas);
                    }
                    catch (SqlException e)
                    {
                        MessageBox.Show("Error al obtener las tarjetas del usuario: " + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            return tarjetas;
        }
        public DataTable ObtenerDireccionesPorUsuario(string userEmail)
        {
            string query = "SELECT Ciudad, Calle, Interseccion, Referencia, Casa FROM Dire WHERE UsuarioEmail = @UsuarioEmail";
            DataTable direcciones = new DataTable();

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@UsuarioEmail", userEmail);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        try
                        {
                            adapter.Fill(direcciones);
                        }
                        catch (SqlException e)
                        {
                            MessageBox.Show("Error al obtener las direcciones del usuario: " + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            return direcciones;
        }
        public string ObtenerDireccionUsuario(string UsuarioEmail)
        {
            string direccion = "";

            string query = "SELECT Calle FROM Dire WHERE UsuarioEmail = @UsuarioEmail";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@UsuarioEmail", UsuarioEmail);

                    conex.Open();

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        direccion = result.ToString();
                    }
                }
            }

            return direccion;
        }


        public string VerificarCredenciales(string email, string contraseña)
        {
            string query = "SELECT NumeroIdentificacion FROM Cuentas WHERE email = @Email AND contraseña = @Contraseña";

            using (SqlCommand cmd = new SqlCommand(query, conex))
            {
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Contraseña", contraseña);

                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    EmailUsuario = email; // Asignar el valor del email a la propiedad EmailUsuario
                    return result.ToString();
                }
            }

            return null;
        }
        public void ActualizarInformacionUsuario(string email, string nombre, string apellido, string telefono, string direccion)
        {
            string queryCuentas = "UPDATE Cuentas SET Nombre = @Nombre, Apellido = @Apellido, Telefono = @Telefono WHERE Email = @Email";
            string queryDire = "UPDATE Dire SET Calle = @Calle WHERE UsuarioEmail = @UsuarioEmail";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmdCuentas = new SqlCommand(queryCuentas, conex))
                {
                    cmdCuentas.Parameters.AddWithValue("@Nombre", nombre);
                    cmdCuentas.Parameters.AddWithValue("@Apellido", apellido);
                    cmdCuentas.Parameters.AddWithValue("@Telefono", telefono);
                    cmdCuentas.Parameters.AddWithValue("@Email", email);

                    conex.Open();
                    cmdCuentas.ExecuteNonQuery();
                }

                using (SqlCommand cmdDire = new SqlCommand(queryDire, conex))
                {
                    cmdDire.Parameters.AddWithValue("@Calle", direccion);
                    cmdDire.Parameters.AddWithValue("@UsuarioEmail", email);

                    cmdDire.ExecuteNonQuery();
                }
            }
        }




        public string ObtenerNombreUsuario(string email)
        {
            string nombre = "";

            string query = "SELECT Nombre FROM Cuentas WHERE email = @Email";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@Email", email);

                    conex.Open();

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        nombre = result.ToString();
                    }
                }
            }

            return nombre;
        }

        public string ObtenerApellidoUsuario(string email)
        {
            string apellido = "";

            string query = "SELECT Apellido FROM Cuentas WHERE email = @Email";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@Email", email);

                    conex.Open();

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        apellido = result.ToString();
                    }
                }
            }

            return apellido;
        }

        public string ObtenerNumeroIdentificacionUsuario(string email)
        {
            string numeroIdentificacion = "";

            string query = "SELECT NumeroIdentificacion FROM Cuentas WHERE email = @Email";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@Email", email);

                    conex.Open();

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        numeroIdentificacion = result.ToString();
                    }
                }
            }

            return numeroIdentificacion;
        }



        public void GuardarCuenta(string documentoIdentificacion, string numeroIdentificacion, string email, string nombre, string apellido, string contraseña, string telefono)
        {
            string query = "INSERT INTO Cuentas (DocumentoIdentificacion, NumeroIdentificacion, Email, Nombre, Apellido, Contraseña, Telefono) VALUES (@DocumentoIdentificacion, @NumeroIdentificacion, @Email, @Nombre, @Apellido, @Contraseña, @Telefono)";

            using (SqlCommand cmd = new SqlCommand(query, conex))
            {
                cmd.Parameters.AddWithValue("@DocumentoIdentificacion", documentoIdentificacion);
                cmd.Parameters.AddWithValue("@NumeroIdentificacion", numeroIdentificacion);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Nombre", nombre);
                cmd.Parameters.AddWithValue("@Apellido", apellido);
                cmd.Parameters.AddWithValue("@Contraseña", contraseña);
                cmd.Parameters.AddWithValue("@Telefono", telefono); // Agregar el parámetro para el teléfono

                cmd.ExecuteNonQuery();
            }
        }
        // Método para obtener el teléfono del usuario por su email
        public string ObtenerTelefonoUsuario(string email)
        {
            string telefono = string.Empty;

            try
            {
                string query = "SELECT Telefono FROM Cuentas WHERE Email = @Email"; // Reemplaza 'tabla_usuarios' con el nombre real de la tabla que contiene la información del usuario

                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@Email", email);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        telefono = reader["Telefono"].ToString();
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                // Manejar la excepción si ocurre algún error en la consulta
                throw new Exception("Error al obtener el teléfono del usuario: " + ex.Message);
            }

            return telefono;
        }

        public bool ActualizarContraseña(string numeroIdentificacion, string nuevaContraseña)
        {
            using (SqlConnection sqlConnection = EstablecerConexion())
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    string query = "UPDATE Cuentas SET contraseña = @NuevaContraseña WHERE NumeroIdentificacion = @NumeroIdentificacion";

                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@NumeroIdentificacion", numeroIdentificacion);
                        cmd.Parameters.AddWithValue("@NuevaContraseña", nuevaContraseña);

                        try
                        {
                            int rowsAffected = cmd.ExecuteNonQuery();

                            return rowsAffected > 0;
                        }
                        catch (SqlException e)
                        {
                            MessageBox.Show("Error al actualizar la contraseña: " + e.Message);
                            return false;
                        }
                    }
                }
                else
                {
                    // La conexión no se estableció correctamente
                    MessageBox.Show("No se pudo establecer la conexión a la base de datos", "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public DataTable ObtenerTarjetas()
        {
            string query = "SELECT Numero, NombreTitular, Año, Mes, CVV FROM Tarjetas";
            DataTable tarjetas = new DataTable();

            using (SqlCommand cmd = new SqlCommand(query, conex))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    try
                    {
                        adapter.Fill(tarjetas);
                    }
                    catch (SqlException e)
                    {
                        MessageBox.Show("Error al obtener las tarjetas: " + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            return tarjetas;
        }

        public void GuardarTarjeta(string numero, string nombreTitular, int año, int mes, string cvv, string emailUsuario)
        {
            string query = "INSERT INTO Tarjetas (Numero, NombreTitular, Año, Mes, CVV, UsuarioEmail) VALUES (@Numero, @NombreTitular, @Año, @Mes, @CVV, @UsuarioEmail)";

            using (SqlCommand cmd = new SqlCommand(query, conex))
            {
                cmd.Parameters.AddWithValue("@Numero", numero);
                cmd.Parameters.AddWithValue("@NombreTitular", nombreTitular);
                cmd.Parameters.AddWithValue("@Año", año);
                cmd.Parameters.AddWithValue("@Mes", mes);
                cmd.Parameters.AddWithValue("@CVV", cvv);
                cmd.Parameters.AddWithValue("@UsuarioEmail", emailUsuario); // Asegúrate de pasar el email del usuario correctamente

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("La tarjeta se ha registrado correctamente.", "Registro exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (SqlException e)
                {
                    MessageBox.Show("Error al registrar la tarjeta: " + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void EliminarRegistroPorEmail(string emailUsuario)
        {

            // Ejemplo:
            string query = "DELETE FROM Tarjetas WHERE UsuarioEmail = @EmailUsuario";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@EmailUsuario", emailUsuario);

                    conex.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        // La clase Comentario se mantiene igual
        public class Comentario
        {
            public string UsuarioEmail { get; set; }
            public string Contenido { get; set; }
            public DateTime Fecha { get; set; }

            public Comentario(string usuarioEmail, string contenido, DateTime fecha)
            {
                UsuarioEmail = usuarioEmail;
                Contenido = contenido;
                Fecha = fecha;
            }
        }


        // Método para insertar el comentario junto con la fecha en la tabla "Comentarios"
        public void InsertarComentario(string UsuarioEmail, string Comentario)
        {
            // Obtener la fecha actual del sistema
            DateTime fechaActual = DateTime.Now;

            // Ejemplo de consulta para insertar el comentario y la fecha en la tabla "Comentarios"
            string query = "INSERT INTO Comentarios (UsuarioEmail, Comentario, Fecha) VALUES (@UsuarioEmail, @Comentario, @Fecha)";

            using (SqlConnection conex = new SqlConnection(CConexion.CadenaConexion))
            {
                using (SqlCommand cmd = new SqlCommand(query, conex))
                {
                    cmd.Parameters.AddWithValue("@UsuarioEmail", UsuarioEmail);
                    cmd.Parameters.AddWithValue("@Comentario", Comentario);
                    cmd.Parameters.AddWithValue("@Fecha", fechaActual); // Asignar la fecha actual al parámetro

                    conex.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static List<Comentario> ObtenerComentariosPorFecha(DateTime fecha)
        {
            List<Comentario> comentariosFiltrados = new List<Comentario>();

            // Establecer el rango de tiempo para la fecha seleccionada (desde el inicio del día hasta el final del día)
            DateTime fechaInicio = fecha.Date; // Hora: 00:00:00
            DateTime fechaFin = fecha.Date.AddDays(1).AddMilliseconds(-1); // Hora: 23:59:59.999

            // Realizar la consulta SQL para obtener los comentarios filtrados por el rango de tiempo
            string query = "SELECT UsuarioEmail, Comentario, Fecha FROM Comentarios WHERE Fecha >= @FechaInicio AND Fecha <= @FechaFin";

            using (SqlConnection connection = new SqlConnection(CadenaConexion))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                    command.Parameters.AddWithValue("@FechaFin", fechaFin);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string usuarioEmail = reader["UsuarioEmail"].ToString();
                            string contenido = reader["Comentario"].ToString();
                            DateTime fechaComentario = (DateTime)reader["Fecha"];

                            // Crear un objeto Comentario con los datos obtenidos y agregarlo a la lista
                            Comentario comentarioObj = new Comentario(usuarioEmail, contenido, fechaComentario);
                            comentariosFiltrados.Add(comentarioObj);
                        }
                    }
                }
            }

            return comentariosFiltrados;
        }




    }
}