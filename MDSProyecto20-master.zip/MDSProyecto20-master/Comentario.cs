﻿using MDSProyecto.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class Comentario : Form
    {
        private string userEmail; // Variable para almacenar el email del usuario
        public Comentario(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail; // Almacenar el email del usuario en la variable userEmail
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el contenido del comentario del RichTextBox
                string comentario = richTextBoxCome.Text;

                // Verificar si el comentario no está vacío
                if (string.IsNullOrEmpty(comentario))
                {
                    MessageBox.Show("Por favor, ingresa un comentario antes de guardar.", "Comentario vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Crear una instancia de la clase CConexion
                CConexion conexion = new CConexion();

                // Llamar al método para insertar el comentario en la base de datos
                conexion.InsertarComentario(userEmail, comentario);

                // Mostrar mensaje de confirmación
                MessageBox.Show("Comentario guardado correctamente.", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);


                // Limpiar el RichTextBox después de guardar el comentario
                richTextBoxCome.Text = "";

                // Cerrar el formulario actual
                this.Close();
            }
            
            catch (Exception ex)
            {
                // Mostrar mensaje de error si ocurrió un problema al guardar el comentario
                MessageBox.Show("Error al guardar el comentario: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
