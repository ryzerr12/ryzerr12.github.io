﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class CostoCoti : Form
    {
        public decimal PesoKilogramos { get; set; }
        public decimal ValorUni { get; set; }
        public int Cantidad { get; set; }

        public CostoCoti(decimal pesoKilogramos, decimal valorUni, int cantidad)
        {
            InitializeComponent();
            // Centrar el formulario en la pantalla
            //this.StartPosition = FormStartPosition.CenterScreen;

            // Deshabilitar botones de minimizar y maximizar
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Deshabilitar el control box (botones de cerrar y barra de título)
            this.ControlBox = false;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            // Deshabilitar el ajuste del tamaño del formulario con el mouse
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Mostrar el formulario en la posición personalizada
            this.StartPosition = FormStartPosition.Manual;
            int screenWidth = Screen.PrimaryScreen.WorkingArea.Width;
            int screenHeight = Screen.PrimaryScreen.WorkingArea.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;
            int formX = screenWidth - formWidth - 160; // 100 píxeles desde el borde derecho
            int formY = screenHeight / 2 - formHeight / 2 - 47; // 50 píxeles más arriba que el centro vertical

            this.Location = new Point(formX, formY);

            // Asignar los valores a las propiedades
            PesoKilogramos = pesoKilogramos;
            ValorUni = valorUni;
            Cantidad = cantidad;

            // Calcular el valor de lblPesoK (Cantidad * PesoKilogramos)
            lblPesoK.Text = (Cantidad * PesoKilogramos).ToString();

            lblValorUni.Text = ValorUni.ToString();
            lblCantidad.Text = Cantidad.ToString();

            // Realizar el cálculo y mostrar el resultado del "ResultadoFlete"
            CalcularResultadoFleteYPrecioTotal();
        }


        private void CostoCoti_Load(object sender, EventArgs e)
        {
            // Mostrar los valores de PesoKilogramos, ValorUni y Cantidad en los Labels correspondientes
            lblPesoK.Text = PesoKilogramos.ToString();
            lblValorUni.Text = ValorUni.ToString();
            lblCantidad.Text = Cantidad.ToString();

            // Realizar el cálculo y mostrar el resultado del "ResultadoFlete"
            CalcularResultadoFleteYPrecioTotal(); 
        }

        private void CalcularResultadoFlete()
        {
            try
            {
                // Calcular el peso total
                decimal pesoTotal = Cantidad * PesoKilogramos;

                // Calcular el resultado del flete según las tarifas establecidas
                decimal resultadoFlete = 0;
                if (pesoTotal >= 50 && pesoTotal <= 799)
                {
                    resultadoFlete = pesoTotal * 0.50m; // 0.50 centavos de dólar por kg
                }
                else if (pesoTotal >= 800 && pesoTotal <= 1400)
                {
                    resultadoFlete = pesoTotal * 0.45m; // 0.45 centavos de dólar por kg
                }

                // Mostrar el resultado del flete en el Label ResultadoFlete
                ResultadoFlete.Text = resultadoFlete.ToString("0.00");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al calcular el resultado del flete: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); // Cierra el formulario si hay errores en el cálculo
            }
        }

        private void CalcularResultadoFleteYPrecioTotal()
        {
            try
            {
                // Llamar al método CalcularResultadoFlete para mostrar el resultado del flete
                CalcularResultadoFlete();

                // Calcular el precio total (ValorUni + resultadoFlete) y mostrarlo en el Label lblPrecio
                decimal valorUni = decimal.Parse(lblValorUni.Text.Replace("$", ""));
                decimal resultadoFlete = decimal.Parse(ResultadoFlete.Text.Replace("Resultado Flete: $", ""));
                decimal precioTotal = valorUni + resultadoFlete;
                lblPrecio.Text =precioTotal.ToString("0.00");

                // Obtener el peso total
                decimal pesoTotal = Cantidad * PesoKilogramos;

                // Verificar si el peso total supera el límite de 1400
                if (pesoTotal > 1400)
                {
                    MessageBox.Show("El peso total de la carga supera el límite de 1400 kg.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al calcular el precio total: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close(); 
            
        }
    }
}




