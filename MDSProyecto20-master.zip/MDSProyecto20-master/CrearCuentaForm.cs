﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class CrearCuentaForm : Form
    {
        public CrearCuentaForm()
        {
            InitializeComponent();
            this.txtContraseña.Click += new System.EventHandler(this.txtContraseña_Click);
            this.txtContraseña.Leave += new System.EventHandler(this.txtContraseña_Leave);
            this.txtConfirmarContraseña.Click += new System.EventHandler(this.txtConfirmarContraseña_Click);
            this.txtConfirmarContraseña.Leave += new System.EventHandler(this.txtConfirmarContraseña_Leave);
            this.txtNumeroIdentificacion.Click += new System.EventHandler(this.txtNumeroIdentificacion_Click);
            this.txtNumeroIdentificacion.Leave += new System.EventHandler(this.txtNumeroIdentificacion_Leave);
            this.txtEmail.Click += new System.EventHandler(this.txtEmail_Click);
            this.txtEmail.Leave += new System.EventHandler(this.txtEmail_Leave);
            this.txtNombre.Click += new System.EventHandler(this.txtNombre_Click);
            this.txtNombre.Leave += new System.EventHandler(this.txtNombre_Leave);
            this.txtApellido.Click += new System.EventHandler(this.txtApellido_Click);
            this.txtApellido.Leave += new System.EventHandler(this.txtApellido_Leave);
            this.txtTelefono.Click += new System.EventHandler(this.txtTelefono_Click);
            this.txtTelefono.Leave += new System.EventHandler(this.txtTelefono_Leave);

            this.Load += CrearCuentaForm_Load;

            this.Text = ""; // Establecer el texto del formulario como una cadena vacía
                            // Asociar el evento KeyPress al TextBox txtTelefono
            txtTelefono.KeyPress += txtTelefono_KeyPress;


        }

        private void CrearCuentaForm_Load(object sender, EventArgs e)
        {

            //cmbDocumentoIdentificacion.Items.Add("Cédula");
            //cmbDocumentoIdentificacion.Items.Add("Pasaporte");

            cmbDocumentoIdentificacion.SelectedIndex = 0; // Establecer el valor predeterminado como "Cédula"

            // Ajustar el tamaño de la ventana al tamaño del PictureBox
            this.Width = pictureBox1.Width;
            this.Height = pictureBox1.Height;

            txtNumeroIdentificacion.Text = "Ingresar...";
            txtNumeroIdentificacion.ForeColor = Color.Gray;

            txtEmail.Text = "Ingresar...";
            txtEmail.ForeColor = Color.Gray;

            txtTelefono.Text = "Ingresar...";
            txtTelefono.ForeColor = Color.Gray;

            txtNombre.Text = "Ingresar...";
            txtNombre.ForeColor = Color.Gray;

            txtApellido.Text = "Ingresar...";
            txtApellido.ForeColor = Color.Gray;

            txtContraseña.Text = "";
            txtContraseña.ForeColor = Color.Black;
            txtContraseña.PasswordChar = '*';

            txtConfirmarContraseña.Text = "";
            txtConfirmarContraseña.ForeColor = Color.Black;
            txtConfirmarContraseña.PasswordChar = '*';

            // Establecer propiedades del formulario
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.ControlBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Centrar el formulario en la pantalla
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        private void txtNumeroIdentificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir solo dígitos numéricos y teclas de control
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Cancelar el evento de tecla
            }
        }

        private void txtNumeroIdentificacion_Validating(object sender, CancelEventArgs e)
        {
            string numeroIdentificacion = txtNumeroIdentificacion.Text.Trim();

            // Verificar la longitud del número de identificación
            if (numeroIdentificacion.Length != 10)
            {
                MessageBox.Show("El número de identificación debe contener exactamente 10 dígitos.");
                txtNumeroIdentificacion.Focus();
                e.Cancel = true; // Cancelar el evento de validación
            }
        }

        

        private void txtNumeroIdentificacion_Click(object sender, EventArgs e)
        {
            if (txtNumeroIdentificacion.Text == "Ingresar...")
            {
                txtNumeroIdentificacion.Text = "";
                txtNumeroIdentificacion.ForeColor = Color.Black;
            }
        }

        private void txtNumeroIdentificacion_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNumeroIdentificacion.Text))
            {
                txtNumeroIdentificacion.Text = "Ingresar...";
                txtNumeroIdentificacion.ForeColor = Color.Gray;
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificar si la tecla presionada es un número y si la longitud actual del texto es menor o igual a 10
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) || txtTelefono.Text.Length >= 10)
            {
                e.Handled = true; // Cancelar el evento de tecla
            }
        }


        private void txtTelefono_Validating(object sender, CancelEventArgs e)
        {
            string Telefono = txtTelefono.Text.Trim();

            // Verificar la longitud del número de identificación
            if (Telefono.Length != 10)
            {
                MessageBox.Show("El número de identificación debe contener exactamente 10 dígitos.");
                txtTelefono.Focus();
                e.Cancel = true; // Cancelar el evento de validación
            }
        }



        private void txtTelefono_Click(object sender, EventArgs e)
        {
            if (txtTelefono.Text == "Ingresar...")
            {
                txtTelefono.Text = "";
                txtTelefono.ForeColor = Color.Black;
            }
        }

        private void txtTelefono_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTelefono.Text))
            {
                txtTelefono.Text = "Ingresar...";
                txtTelefono.ForeColor = Color.Gray;
            }
        }

        private void txtEmail_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text == "Ingresar...")
            {
                txtEmail.Text = "";
                txtEmail.ForeColor = Color.Black;
            }
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                txtEmail.Text = "Ingresar...";
                txtEmail.ForeColor = Color.Gray;
            }
        }

        private void txtNombre_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "Ingresar...")
            {
                txtNombre.Text = "";
                txtNombre.ForeColor = Color.Black;
            }
        }

        private void txtNombre_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNombre.Text))
            {
                txtNombre.Text = "Ingresar...";
                txtNombre.ForeColor = Color.Gray;
            }
        }

        private void txtApellido_Click(object sender, EventArgs e)
        {
            if (txtApellido.Text == "Ingresar...")
            {
                txtApellido.Text = "";
                txtApellido.ForeColor = Color.Black;
            }
        }

        private void txtApellido_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtApellido.Text))
            {
                txtApellido.Text = "Ingresar...";
                txtApellido.ForeColor = Color.Gray;
            }
        }

        private void txtContraseña_Click(object sender, EventArgs e)
        {
            if (txtContraseña.Text == "Ingresar...")
            {
                txtContraseña.Text = "";
                txtContraseña.ForeColor = Color.Black;
                txtContraseña.PasswordChar = '*';
            }
        }

        private void txtContraseña_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtContraseña.Text))
            {
                txtContraseña.Text = "Ingresar...";
                txtContraseña.ForeColor = Color.Gray;
                txtContraseña.PasswordChar = '\0'; // Eliminar el carácter de contraseña para mostrar el texto de marcador de posición
            }
        }

        private void txtConfirmarContraseña_Click(object sender, EventArgs e)
        {
            if (txtConfirmarContraseña.Text == "Ingresar...")
            {
                txtConfirmarContraseña.Text = "";
                txtConfirmarContraseña.ForeColor = Color.Black;
                txtConfirmarContraseña.PasswordChar = '*';
            }
        }

        private void txtConfirmarContraseña_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtConfirmarContraseña.Text))
            {
                txtConfirmarContraseña.Text = "Ingresar...";
                txtConfirmarContraseña.ForeColor = Color.Gray;
                txtConfirmarContraseña.PasswordChar = '\0'; // Eliminar el carácter de contraseña para mostrar el texto de marcador de posición
            }
        }

        private void btnCrearCuenta_Click(object sender, EventArgs e)
        {
            if (cmbDocumentoIdentificacion.SelectedItem == null ||
                string.IsNullOrWhiteSpace(txtNumeroIdentificacion.Text) ||
                txtNumeroIdentificacion.Text.Length != 10 ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtContraseña.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmarContraseña.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtContraseña.Text != txtConfirmarContraseña.Text)
            {
                MessageBox.Show("Las contraseñas no coinciden. Por favor, asegúrese de que las contraseñas sean iguales.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                string documentoIdentificacion = cmbDocumentoIdentificacion.SelectedItem.ToString();
                string numeroIdentificacion = txtNumeroIdentificacion.Text;
                string email = txtEmail.Text;
                string nombre = txtNombre.Text;
                string apellido = txtApellido.Text;
                string contraseña = txtContraseña.Text;

                // Aquí puedes utilizar tu clase CConexion para guardar los datos en la base de datos
                // Ejemplo: objetoConexion.GuardarCuenta(documentoIdentificacion, numeroIdentificacion, email, nombre, apellido, contraseña);

                MessageBox.Show("La cuenta se ha creado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Mostrar el Form1 y ocultar el CrearCuentaForm
                Form1 form1 = new Form1();
                form1.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear la cuenta: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnCrearCuenta_Click_1(object sender, EventArgs e)
        {
            string tipoDocumento = cmbDocumentoIdentificacion.SelectedItem.ToString();
            string numeroIdentificacion = txtNumeroIdentificacion.Text;
            string email = txtEmail.Text;
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            string contraseña = txtContraseña.Text;
            string confirmarContraseña = txtConfirmarContraseña.Text;

            // Obtener el valor del TextBox txtTelefono
            string telefono = txtTelefono.Text;

            if (string.IsNullOrEmpty(numeroIdentificacion) || string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) ||
                string.IsNullOrEmpty(contraseña) || string.IsNullOrEmpty(confirmarContraseña))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            if (contraseña != confirmarContraseña)
            {
                MessageBox.Show("Las contraseñas no coinciden. Por favor, verifique.");
                return;
            }

            Clases.CConexion conexion = new Clases.CConexion();
            SqlConnection sqlConnection = conexion.EstablecerConexion(); // Establecer conexión con la base de datos

            if (sqlConnection.State == ConnectionState.Open)
            {
                // Validar la unicidad del número de identificación
                if (!EsNumeroIdentificacionUnico(sqlConnection, numeroIdentificacion))
                {
                    MessageBox.Show("El número de identificación ya está en uso. Por favor, elija otro número de identificación.");
                    return;
                }

                // Validar la unicidad del email
                if (!EsEmailUnico(sqlConnection, email))
                {
                    MessageBox.Show("El email ya está en uso. Por favor, elija otro email.");
                    return;
                }

                // Guardar la cuenta en la base de datos
                conexion.GuardarCuenta(tipoDocumento, numeroIdentificacion, email, nombre, apellido, contraseña, telefono);

                MessageBox.Show("La cuenta se creó correctamente.");

                // Cerrar la instancia actual de CrearCuentaForm y mostrar la instancia existente de Form1
                this.Close();
                Form1.Instance.Show();

                sqlConnection.Close(); // Cerrar la conexión después de usarla
            }
            else
            {
                MessageBox.Show("No se pudo establecer la conexión a la base de datos", "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private bool EsNumeroIdentificacionUnico(SqlConnection sqlConnection, string numeroIdentificacion)
        {
            // Realizar la consulta en la base de datos para verificar la unicidad del número de identificación
            string query = "SELECT COUNT(*) FROM Cuentas WHERE NumeroIdentificacion = @NumeroIdentificacion";

            using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
            {
                cmd.Parameters.AddWithValue("@NumeroIdentificacion", numeroIdentificacion);

                try
                {
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    return count == 0; // Si count es igual a 0, significa que el número de identificación es único
                }
                catch (SqlException e)
                {
                    MessageBox.Show("Error al verificar el número de identificación: " + e.Message);
                    return false;
                }
            }
        }

        private bool EsEmailUnico(SqlConnection sqlConnection, string email)
        {
            // Realizar la consulta en la base de datos para verificar la unicidad del email
            string query = "SELECT COUNT(*) FROM Cuentas WHERE Email = @Email";

            using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
            {
                cmd.Parameters.AddWithValue("@Email", email);

                try
                {
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    return count == 0; // Si count es igual a 0, significa que el email es único
                }
                catch (SqlException e)
                {
                    MessageBox.Show("Error al verificar el email: " + e.Message);
                    return false;
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            // Volver al formulario Form1
            this.Hide();
            Form1.Instance.Show();
        }
    }
}














