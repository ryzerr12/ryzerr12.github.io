﻿using MDSProyecto.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class DireccionesForm : Form
    {
        static string servidor = "localhost";
        static string bd = "pp";
        static string usuario = "prueba";
        static string password = "12345";
        static string puerto = "1433";

        string connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";
        public DireccionesForm()
        {
            InitializeComponent();
            LoadData();
            CustomizeDataGridView();

            // Establecer propiedades del formulario
            this.StartPosition = FormStartPosition.CenterScreen; // Aparecer en el centro de la pantalla
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Evitar que se pueda cambiar el tamaño
            this.MaximizeBox = false; // Deshabilitar el botón de maximizar
            this.MinimizeBox = false; // Deshabilitar el botón de minimizar
            this.ControlBox = false; // Ocultar la barra de título (los botones de cerrar, minimizar y maximizar)
            

            

            // Ocultar el título del formulario
            this.Text = string.Empty;

            
        }
        private void DireccionesForm_Load(object sender, EventArgs e)
        {
            CargarDirecciones();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Cerrar el formulario actual
            this.Close();

            // Abrir el formulario "RegDire" y pasar una instancia de "CConexion"
            CConexion conexion = new CConexion();
            RegDire regDireForm = new RegDire(conexion);
            regDireForm.Show();
        }
        private void LoadData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Consulta SQL para seleccionar solo las columnas deseadas y en el orden requerido
                    string query = "SELECT [Calle], [Referencia], [Ciudad] FROM [dbo].[Dire] WHERE UsuarioEmail = @UsuarioEmail";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Agregar el parámetro del correo electrónico del usuario
                        command.Parameters.AddWithValue("@UsuarioEmail", Form2.EmailUsuario);

                        // Crear un adaptador de datos para leer los resultados de la consulta
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            // Crear un DataSet para contener los datos
                            DataSet dataSet = new DataSet();

                            // Llenar el DataSet con los resultados de la consulta
                            adapter.Fill(dataSet);

                            // Asignar el DataTable del DataSet como origen de datos del DataGridView
                            dataGridViewDire.DataSource = dataSet.Tables[0];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void CargarDirecciones()
        {
            try
            {
                // Obtener los datos de las direcciones desde la base de datos para el usuario actual
                CConexion conexion = new CConexion();
                DataTable direcciones = conexion.ObtenerDireccionesPorUsuario(Form2.EmailUsuario); // Método para obtener los datos de las direcciones filtradas por usuario

                // Mostrar los datos en el DataGridView
                dataGridViewDire.DataSource = direcciones;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las direcciones: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void CustomizeDataGridView()
        {
            // Establecer el modo de ajuste de columnas a None para que no se ajusten automáticamente
            dataGridViewDire.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            // Ajustar el ancho de cada columna individualmente (puedes ajustar los valores según tus necesidades)
            dataGridViewDire.Columns["Calle"].Width = 210;
            dataGridViewDire.Columns["Referencia"].Width = 210;
            dataGridViewDire.Columns["Ciudad"].Width = 140;

            // Ocultar los títulos de las columnas
            dataGridViewDire.ColumnHeadersVisible = false;

            //dataGridViewDire.RowHeadersVisible = false; // Para ocultar la columna de encabezado de filas
            // dataGridViewDire.DefaultCellStyle.WrapMode = DataGridViewTriState.True; // Para permitir el ajuste de texto en celdas largas

            // Finalmente, desactivar la ordenación de columnas haciendo clic en los encabezados
            foreach (DataGridViewColumn column in dataGridViewDire.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
