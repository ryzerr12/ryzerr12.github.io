﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace MDSProyecto
{
    public partial class EntregadoForm : Form
    {
        private string userEmail;
        private string connectionString;
        private static EntregadoForm instance;

        private List<Producto> datosFactura = new List<Producto>();
        private string UsuarioEmail { get; set; }

        public class Producto
        {
            public int ID { get; set; }
            public string ProEnviar { get; set; }
            public decimal PesoKg { get; set; }
            public decimal ValorUni { get; set; }
            public int Cantidad { get; set; }
            public decimal Ancho { get; set; }
            public decimal Alto { get; set; }
            public decimal Largo { get; set; }
            public bool Seleccionar { get; set; }
        }

        public EntregadoForm(string userEmail)
        {
            this.userEmail = userEmail;
            InitializeComponent();
            string servidor = "localhost";
            string bd = "pp";
            string usuario = "prueba";
            string password = "12345";
            string puerto = "1433";
            connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

            LoadData();
            CustomizeDataGridView();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            if (instance != null && !instance.IsDisposed)
            {
                instance.Focus();
                this.Close(); // Cerrar el formulario actual
                return;
            }

            // Mostrar el formulario
            this.Show();

            // Suscribirse al evento CellClick para seleccionar toda la fila al hacer clic en cualquier parte de ella
            dataGridViewFactura.CellClick += DataGridViewFactura_CellClick;

            this.UsuarioEmail = userEmail;
        }

        private void LoadData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Consulta SQL para seleccionar solo las columnas deseadas y en el orden requerido
                    string query = "SELECT [ID], [ProEnviar], [PesoKg], [ValorUni], [Cantidad], [Ancho], [Alto], [Largo], [Seleccionar] FROM [dbo].[TablaDestino] WHERE UsuarioEmail = @UsuarioEmail";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Agregar el parámetro del correo electrónico del usuario
                        command.Parameters.AddWithValue("@UsuarioEmail", userEmail);

                        // Crear un adaptador de datos para leer los resultados de la consulta
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            // Asignar el comando al adaptador
                            adapter.SelectCommand = command;

                            // Crear un DataSet para contener los datos
                            DataSet dataSet = new DataSet();

                            // Llenar el DataSet con los resultados de la consulta
                            adapter.Fill(dataSet);

                            // Convertir los valores nulos a DBNull en el DataSet antes de asignarlos al DataGridView
                            foreach (DataRow row in dataSet.Tables[0].Rows)
                            {
                                if (row["Largo"] == DBNull.Value)
                                {
                                    row["Largo"] = DBNull.Value;
                                }
                            }

                            // Asignar el DataTable del DataSet como origen de datos del DataGridView
                            dataGridViewFactura.DataSource = dataSet.Tables[0];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void CustomizeDataGridView()
        {
            // Establecer el modo de ajuste de columnas a None para que no se ajusten automáticamente
            dataGridViewFactura.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            // Ajustar el ancho de cada columna individualmente (puedes ajustar los valores según tus necesidades)
            dataGridViewFactura.Columns["ID"].Width = 30;
            dataGridViewFactura.Columns["ProEnviar"].Width = 240;
            dataGridViewFactura.Columns["PesoKg"].Width = 60;
            dataGridViewFactura.Columns["ValorUni"].Width = 60;
            dataGridViewFactura.Columns["Cantidad"].Width = 60;
            dataGridViewFactura.Columns["Ancho"].Width = 50;
            dataGridViewFactura.Columns["Alto"].Width = 50;
            dataGridViewFactura.Columns["Largo"].Width = 40;

            // Verificar si la columna "Seleccionar" existe en el DataGridView
            bool columnaSeleccionarExiste = dataGridViewFactura.Columns.Cast<DataGridViewColumn>().Any(col => col.Name == "Seleccionar");

            if (!columnaSeleccionarExiste)
            {
                // Si la columna "Seleccionar" no existe, crearla y agregarla al DataGridView
                DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
                checkBoxColumn.Name = "Seleccionar";
                checkBoxColumn.HeaderText = "Seleccionar";
                checkBoxColumn.TrueValue = true;
                checkBoxColumn.FalseValue = false;
                checkBoxColumn.ThreeState = false; // Si deseas permitir el valor nulo, cambia esto a true.
                checkBoxColumn.Width = 80;
                dataGridViewFactura.Columns.Add(checkBoxColumn);
            }

            // Visualmente mostrar la casilla de verificación en la columna "Seleccionar"
            dataGridViewFactura.Columns["Seleccionar"].Visible = true;

            // Finalmente, desactivar la ordenación de columnas haciendo clic en los encabezados
            foreach (DataGridViewColumn column in dataGridViewFactura.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        private void DataGridViewFactura_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificar si se hizo clic en cualquier parte de la fila (excepto en la columna de CheckBox "Seleccionar")
            if (e.RowIndex >= 0 && e.ColumnIndex != -1 && dataGridViewFactura.Columns.Contains("Seleccionar"))
            {
                // Obtener la columna "Seleccionar"
                DataGridViewColumn checkBoxColumn = dataGridViewFactura.Columns["Seleccionar"];

                // Verificar si el índice de la columna es igual al índice de la columna "Seleccionar"
                if (e.ColumnIndex == checkBoxColumn.Index)
                {
                    // Obtener la fila donde se hizo clic
                    DataGridViewRow row = dataGridViewFactura.Rows[e.RowIndex];

                    // Obtener el CheckBoxCell de la columna "Seleccionar" para esa fila
                    DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)row.Cells["Seleccionar"];

                    // Cambiar el valor de la casilla de verificación (seleccionar o deseleccionar)
                    checkBoxCell.Value = !(bool)checkBoxCell.Value;

                    // Indicar que la edición de la celda ha finalizado para que el valor se refleje en el modelo de datos
                    dataGridViewFactura.EndEdit();
                }
            }
        }

        private void btnGenerarFactura_Click(object sender, EventArgs e)
        {
            List<DataGridViewRow> productosSeleccionados = new List<DataGridViewRow>();

            // Obtener todas las filas seleccionadas en el DataGridView
            foreach (DataGridViewRow row in dataGridViewFactura.Rows)
            {
                DataGridViewCheckBoxCell checkBoxCell = row.Cells["Seleccionar"] as DataGridViewCheckBoxCell;

                // Verificar si la casilla de verificación está marcada
                if (Convert.ToBoolean(checkBoxCell?.Value) == true)
                {
                    // Agregar la fila a la lista de productos seleccionados
                    productosSeleccionados.Add(row);
                }
            }

            // Verificar si se ha seleccionado algún producto
            if (productosSeleccionados.Count == 0)
            {
                MessageBox.Show("No has seleccionado ningún producto para generar la factura.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Obtener un número aleatorio para el número de factura
            Random random = new Random();
            int numeroFactura = random.Next(1, 1000); // Cambia los valores 1 y 1000 según tus necesidades

            // Obtener la fecha de emisión de la tabla "TablaDestino"
            DateTime fechaEmision;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string queryFechaEmision = "SELECT TOP 1 Fecha FROM TablaDestino WHERE UsuarioEmail = @UsuarioEmail ORDER BY Fecha DESC";
                using (SqlCommand command = new SqlCommand(queryFechaEmision, connection))
                {
                    command.Parameters.AddWithValue("@UsuarioEmail", userEmail);
                    object result = command.ExecuteScalar();
                    fechaEmision = (DateTime)result;
                }
            }

            // Obtener el nombre, apellido y dirección del cliente de las tablas "Cuentas" y "Dire"
            string nombreCliente = string.Empty;
            string apellidoCliente = string.Empty;
            string direccionCliente = string.Empty;
            string documentoIdentificacionCliente = string.Empty;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Consulta para obtener el nombre y apellido del cliente de la tabla "Cuentas"
                string queryCliente = "SELECT TOP 1 Nombre, Apellido, NumeroIdentificacion FROM Cuentas WHERE Email = @Email";
                using (SqlCommand command = new SqlCommand(queryCliente, connection))
                {
                    command.Parameters.AddWithValue("@Email", userEmail);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            nombreCliente = reader["Nombre"].ToString();
                            apellidoCliente = reader["Apellido"].ToString();
                            documentoIdentificacionCliente = reader["NumeroIdentificacion"].ToString();
                        }
                    }
                }

                // Consulta para obtener la dirección del cliente de la tabla "Dire"
                string queryDireccion = "SELECT TOP 1 Calle FROM Dire WHERE UsuarioEmail = @UsuarioEmail";
                using (SqlCommand command = new SqlCommand(queryDireccion, connection))
                {
                    command.Parameters.AddWithValue("@UsuarioEmail", userEmail);
                    object result = command.ExecuteScalar();
                    direccionCliente = result?.ToString(); // Use el operador "?" para asegurarse de que "result" no sea nulo
                }

                // Verificar si se encontró la dirección en la tabla "Dire"
                if (string.IsNullOrEmpty(direccionCliente))
                {
                    // Mostrar un mensaje indicando que el cliente no tiene registrada una dirección
                    MessageBox.Show("No tiene registrada una dirección.", "Dirección no encontrada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }


            // Crear el objeto SaveFileDialog para que el usuario seleccione la ubicación y el nombre del archivo PDF
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Archivo PDF (.pdf)|.pdf";
                saveFileDialog.Title = "Guardar Factura PDF";
                saveFileDialog.FileName = "Factura.pdf"; // Nombre predeterminado del archivo

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Obtener la ruta seleccionada por el usuario
                    string rutaArchivo = saveFileDialog.FileName;

                    // Crear el documento PDF
                    using (Document document = new Document(PageSize.A4, 50f, 50f, 70f, 70f))
                    {
                        // Crear el objeto PdfWriter para escribir en el archivo
                        using (FileStream fs = new FileStream(rutaArchivo, FileMode.Create))
                        {
                            PdfWriter.GetInstance(document, fs);

                            // Abrir el documento
                            document.Open();

                            // Crear una tabla para el encabezado de la factura
                            PdfPTable tablaEncabezado = new PdfPTable(3); // Reducimos el número de columnas a 3
                            tablaEncabezado.WidthPercentage = 100f;

                            // Celda para el logo
                            iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(Properties.Resources.dll, System.Drawing.Imaging.ImageFormat.Png);
                            logo.ScalePercent(100f); // Ajustar el tamaño del logo según tus necesidades
                            PdfPCell cellLogo = new PdfPCell(logo);
                            cellLogo.Border = iTextSharp.text.Rectangle.NO_BORDER;
                            tablaEncabezado.AddCell(cellLogo);

                            // Celda vacía para el espacio en blanco entre el logo y el texto "FACTURA"
                            PdfPCell cellEspacio = new PdfPCell();
                            cellEspacio.Border = iTextSharp.text.Rectangle.NO_BORDER;
                            tablaEncabezado.AddCell(cellEspacio);

                            // Celda combinada para el texto "FACTURA" y el número de factura
                            PdfPCell cellFactura = new PdfPCell();
                            cellFactura.Border = iTextSharp.text.Rectangle.NO_BORDER; // Establecer el borde como transparente
                            cellFactura.Colspan = 2; // Combinar dos columnas

                            // Crear una tabla interna con dos filas para el texto "FACTURA" y el número de factura
                            PdfPTable tablaFactura = new PdfPTable(1);
                            PdfPCell cellTextoFactura = new PdfPCell(new Phrase("FACTURA", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 14f, iTextSharp.text.Font.BOLD)));
                            cellTextoFactura.HorizontalAlignment = Element.ALIGN_CENTER;
                            tablaFactura.AddCell(cellTextoFactura);

                            PdfPCell cellNumeroFactura = new PdfPCell(new Phrase(numeroFactura.ToString(), new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 14f, iTextSharp.text.Font.BOLD)));
                            cellNumeroFactura.HorizontalAlignment = Element.ALIGN_CENTER;
                            tablaFactura.AddCell(cellNumeroFactura);

                            // Agregar la tabla interna a la celda combinada
                            cellFactura.AddElement(tablaFactura);

                            // Agregar la celda combinada a la tabla del encabezado
                            tablaEncabezado.AddCell(cellFactura);

                            // Agregar tabla de encabezado al documento
                            document.Add(tablaEncabezado);


                            // Agregar información básica de la factura (Número, Fecha, Cliente, etc.)
                            Paragraph encabezadoFactura = new Paragraph();
                            encabezadoFactura.Alignment = Element.ALIGN_LEFT;
                            //encabezadoFactura.Add($"Número de Factura: {numeroFactura}\n");
                            encabezadoFactura.Add($"Fecha: {fechaEmision.ToString("dd/MM/yyyy")}\n");
                            encabezadoFactura.Add($"Cliente: {nombreCliente} {apellidoCliente}\n");
                            encabezadoFactura.Add($"Dirección: {direccionCliente}\n");
                            encabezadoFactura.Add($"Pasaporte/Cédula: {documentoIdentificacionCliente}\n\n");
                            document.Add(encabezadoFactura);

                            // Agregar la tabla con la descripción de los productos
                            PdfPTable tablaProductos = new PdfPTable(6); // 6 columnas para: Descripción, Cantidad, Precio Unitario, Peso (kg), Precio (Kg), Total
                            tablaProductos.WidthPercentage = 100f;
                            tablaProductos.HorizontalAlignment = Element.ALIGN_LEFT; // Alinear la tabla a la izquierda
                            iTextSharp.text.Rectangle rec = new iTextSharp.text.Rectangle(PageSize.A4);
                            tablaProductos.DefaultCell.Padding = 5f;

                            // Agregar las cabeceras de las columnas con formato en negrita
                            PdfPCell cellDescripcion = new PdfPCell(new Phrase(new Chunk("Descripción", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12f, iTextSharp.text.Font.BOLD))));
                            PdfPCell cellCantidad = new PdfPCell(new Phrase(new Chunk("Cantidad", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12f, iTextSharp.text.Font.BOLD))));
                            PdfPCell cellPrecioUnitario = new PdfPCell(new Phrase(new Chunk("Precio Unitario", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12f, iTextSharp.text.Font.BOLD))));
                            PdfPCell cellPesoKg = new PdfPCell(new Phrase(new Chunk("Peso (kg)", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12f, iTextSharp.text.Font.BOLD))));
                            PdfPCell cellPrecioKg = new PdfPCell(new Phrase(new Chunk("Precio (Kg)", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12f, iTextSharp.text.Font.BOLD))));
                            PdfPCell cellTotal = new PdfPCell(new Phrase(new Chunk("Total", new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12f, iTextSharp.text.Font.BOLD))));

                            // Establecer alineación del texto de las celdas de encabezado a la izquierda
                            cellDescripcion.HorizontalAlignment = Element.ALIGN_LEFT;
                            cellCantidad.HorizontalAlignment = Element.ALIGN_LEFT;
                            cellPrecioUnitario.HorizontalAlignment = Element.ALIGN_LEFT;
                            cellPesoKg.HorizontalAlignment = Element.ALIGN_LEFT;
                            cellPrecioKg.HorizontalAlignment = Element.ALIGN_LEFT;
                            cellTotal.HorizontalAlignment = Element.ALIGN_LEFT;

                            // Agregar las celdas con las cabeceras de las columnas a la tabla
                            tablaProductos.AddCell(cellDescripcion);
                            tablaProductos.AddCell(cellCantidad);
                            tablaProductos.AddCell(cellPrecioUnitario);
                            tablaProductos.AddCell(cellPesoKg);
                            tablaProductos.AddCell(cellPrecioKg);
                            tablaProductos.AddCell(cellTotal);

                            // Calcular y agregar información de cada producto seleccionado al PDF
                            decimal subtotal = 0;
                            foreach (DataGridViewRow row in productosSeleccionados)
                            {
                                string proEnviar = row.Cells["ProEnviar"].Value.ToString();
                                int cantidad = Convert.ToInt32(row.Cells["Cantidad"].Value);
                                decimal valorUni = Convert.ToDecimal(row.Cells["ValorUni"].Value);
                                decimal pesoKg = Convert.ToDecimal(row.Cells["PesoKg"].Value);

                                // Calcular el precio por kg según las condiciones especificadas
                                decimal precioPorKg = 0.50m; // Precio por defecto
                                if (pesoKg >= 50 && pesoKg <= 799)
                                {
                                    precioPorKg = 0.50m;
                                }
                                else if (pesoKg >= 800 && pesoKg <= 1400)
                                {
                                    precioPorKg = 0.45m;
                                }

                                // Calcular el total del producto teniendo en cuenta el precio por kg
                                decimal totalProducto = (cantidad * pesoKg * ((pesoKg >= 800 && pesoKg <= 1400) ? 0.45m : 0.50m)) + valorUni;
                                subtotal += totalProducto;

                                // Agregar la información del producto a la tabla
                                tablaProductos.AddCell(proEnviar);
                                tablaProductos.AddCell(cantidad.ToString());
                                tablaProductos.AddCell(valorUni.ToString("C")); // Precio Unitario formateado como moneda
                                tablaProductos.AddCell(pesoKg.ToString()); // Agregar el valor del Peso (kg) en formato de texto sin formato de moneda
                                tablaProductos.AddCell(precioPorKg.ToString("C")); // Precio (Kg) formateado como moneda
                                tablaProductos.AddCell(totalProducto.ToString("C")); // Total formateado como moneda
                            }


                            // Agregar la tabla al documento
                            document.Add(tablaProductos);

                            // Calcular el subtotal con el 12% de descuento (subtotal - 12%)
                            decimal subtotalConDescuento = subtotal * 0.88m;

                            // Agregar el subtotal con descuento al documento
                            document.Add(new Paragraph("\n"));
                            Paragraph subtotalConDescuentoParagraph = new Paragraph();
                            subtotalConDescuentoParagraph.Alignment = Element.ALIGN_RIGHT;
                            subtotalConDescuentoParagraph.Add($"Subtotal: {subtotalConDescuento.ToString("C")}\n");
                            document.Add(subtotalConDescuentoParagraph);

                            // Calcular el valor del impuesto/tasa (subtotal original - subtotal con descuento)
                            decimal impuestosTasas = subtotal - subtotalConDescuento;                          

                            // Calcular el total (subtotal con descuento + impuestos/tasas)
                            decimal total = subtotalConDescuento + impuestosTasas;

                            // Crear un estilo de alineación a la izquierda para el IVA 12% y Total
                            iTextSharp.text.Paragraph ivaAndTotalLeftAligned = new iTextSharp.text.Paragraph($"IVA 12%: {impuestosTasas.ToString("C")}\nTotal: {total.ToString("C")}");
                            ivaAndTotalLeftAligned.Alignment = iTextSharp.text.Element.ALIGN_RIGHT;

                            // Agregar los párrafos con estilos de alineación al documento
                            document.Add(ivaAndTotalLeftAligned);

                            // Definir las opciones de condiciones de pago
                            List<string> opcionesCondicionesPago = new List<string> { "Tarjeta de crédito", "Tarjeta de Débito" };

                            // Generar un número aleatorio para seleccionar una de las opciones
                            int randomNumber = random.Next(0, opcionesCondicionesPago.Count);

                            // Mostrar la opción aleatoria según el número generado
                            string condicionPago = opcionesCondicionesPago[randomNumber];
                            document.Add(new Paragraph($"Condiciones de pago: {condicionPago}\n"));

                            // Cerrar el documento
                            document.Close();

                            // Después de generar la factura, eliminar los productos seleccionados de la base de datos
                            EliminarProductosSeleccionados(productosSeleccionados);
                        }
                    }

                    // Mostrar un mensaje al usuario indicando que el PDF se ha generado correctamente
                    MessageBox.Show("Factura generada correctamente.", "Generar Factura PDF", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Cerrar el formulario actual (AgendaServicio.cs)
                    this.Close();
                }
            }
        }




        

        private void EntregadoForm_Load(object sender, EventArgs e)
        {
            // Llamar al método CustomizeDataGridView después de cargar los datos en el DataGridView
            CustomizeDataGridView();
        }

        private void EliminarProductosSeleccionados(List<DataGridViewRow> productosSeleccionados)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (DataGridViewRow row in productosSeleccionados)
                    {
                        int productoID = Convert.ToInt32(row.Cells["ID"].Value);

                        // Consulta SQL para eliminar el producto de la base de datos por su ID
                        string query = "DELETE FROM [dbo].[TablaDestino] WHERE ID = @ProductoID";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Agregar el parámetro del ID del producto
                            command.Parameters.AddWithValue("@ProductoID", productoID);

                            // Ejecutar la consulta para eliminar el producto
                            command.ExecuteNonQuery();
                        }
                    }

                    // Recargar los datos en el DataGridView después de eliminar los productos
                    LoadData();

                    // Mostrar un mensaje al usuario indicando que los productos se han eliminado correctamente
                    //MessageBox.Show("Gracias por confiar en nosotros", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar los productos seleccionados: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCaja_Click(object sender, EventArgs e)
        {
            // Obtener el email del usuario actual desde la variable userEmail
            string emailUsuario = userEmail;

            // Crear una instancia del formulario ComentariosForm y pasar el email del usuario como parámetro
            Comentario comentariosForm = new Comentario(emailUsuario);

            // Mostrar el formulario ComentariosForm de manera modal
            comentariosForm.ShowDialog();
        }


    }
}
