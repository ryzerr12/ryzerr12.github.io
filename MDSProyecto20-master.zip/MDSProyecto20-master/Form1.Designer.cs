﻿namespace MDSProyecto
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.TextBox jTxtUsuario;
        private System.Windows.Forms.TextBox jPassClave;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Button btncrea;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkOlvidasteContraseña;

        private void InitializeComponent()
        {
            this.title = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.jTxtUsuario = new System.Windows.Forms.TextBox();
            this.passLabel = new System.Windows.Forms.Label();
            this.jPassClave = new System.Windows.Forms.TextBox();
            this.loginButton = new System.Windows.Forms.Button();
            this.btncrea = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkOlvidasteContraseña = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.Location = new System.Drawing.Point(0, 0);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(86, 20);
            this.title.TabIndex = 6;
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.userLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userLabel.Location = new System.Drawing.Point(404, 146);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(127, 15);
            this.userLabel.TabIndex = 1;
            this.userLabel.Text = "Tu correo electrónico *";
            // 
            // jTxtUsuario
            // 
            this.jTxtUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jTxtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jTxtUsuario.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jTxtUsuario.Location = new System.Drawing.Point(415, 165);
            this.jTxtUsuario.Name = "jTxtUsuario";
            this.jTxtUsuario.Size = new System.Drawing.Size(180, 22);
            this.jTxtUsuario.TabIndex = 2;
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.passLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passLabel.Location = new System.Drawing.Point(404, 205);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(89, 15);
            this.passLabel.TabIndex = 3;
            this.passLabel.Text = "Tu contraseña *";
            // 
            // jPassClave
            // 
            this.jPassClave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jPassClave.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jPassClave.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jPassClave.Location = new System.Drawing.Point(415, 231);
            this.jPassClave.Name = "jPassClave";
            this.jPassClave.PasswordChar = '*';
            this.jPassClave.Size = new System.Drawing.Size(180, 22);
            this.jPassClave.TabIndex = 4;
            // 
            // loginButton
            // 
            this.loginButton.BackColor = System.Drawing.Color.Black;
            this.loginButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loginButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.loginButton.Location = new System.Drawing.Point(403, 288);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(199, 31);
            this.loginButton.TabIndex = 5;
            this.loginButton.Text = "Iniciar sesión";
            this.loginButton.UseVisualStyleBackColor = false;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // btncrea
            // 
            this.btncrea.BackColor = System.Drawing.Color.Black;
            this.btncrea.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncrea.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncrea.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.btncrea.Location = new System.Drawing.Point(403, 342);
            this.btncrea.Name = "btncrea";
            this.btncrea.Size = new System.Drawing.Size(199, 31);
            this.btncrea.TabIndex = 7;
            this.btncrea.Text = "Crear una cuenta";
            this.btncrea.UseVisualStyleBackColor = false;
            this.btncrea.Click += new System.EventHandler(this.btncrea_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MDSProyecto.Properties.Resources.decoingreso;
            this.pictureBox1.Location = new System.Drawing.Point(3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(654, 437);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // linkOlvidasteContraseña
            // 
            this.linkOlvidasteContraseña.ActiveLinkColor = System.Drawing.Color.DodgerBlue;
            this.linkOlvidasteContraseña.AutoSize = true;
            this.linkOlvidasteContraseña.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.linkOlvidasteContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkOlvidasteContraseña.LinkColor = System.Drawing.Color.Black;
            this.linkOlvidasteContraseña.Location = new System.Drawing.Point(521, 209);
            this.linkOlvidasteContraseña.Name = "linkOlvidasteContraseña";
            this.linkOlvidasteContraseña.Size = new System.Drawing.Size(130, 13);
            this.linkOlvidasteContraseña.TabIndex = 9;
            this.linkOlvidasteContraseña.TabStop = true;
            this.linkOlvidasteContraseña.Text = "¿Olvidaste tu contraseña?";
            this.linkOlvidasteContraseña.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkOlvidasteContraseña_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 439);
            this.Controls.Add(this.linkOlvidasteContraseña);
            this.Controls.Add(this.btncrea);
            this.Controls.Add(this.loginButton);
            this.Controls.Add(this.jPassClave);
            this.Controls.Add(this.passLabel);
            this.Controls.Add(this.jTxtUsuario);
            this.Controls.Add(this.userLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.title);
            this.Name = "Form1";
            this.Text = "Inicio de Sesión";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}



