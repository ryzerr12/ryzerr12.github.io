﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MDSProyecto.Properties;
using MDSProyecto.Clases;

namespace MDSProyecto
{
    public partial class Form1 : Form
    {
        // Variable para almacenar el correo electrónico del usuario
        public string UsuarioEmail { get; set; }
        public static Form1 Instance { get; private set; } // Agregar la propiedad estática

        //AGERGADO 22:12


        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=localhost,1433;Initial Catalog=pp;User ID=prueba;Password=12345;";

        // Nombre de la tabla
        private string tableName = "ContadorPorCliente";



        public Form1()
        {
            InitializeComponent();
            Instance = this; // Asignar la instancia actual a la propiedad estática
            pictureBox1.Image = Resources.decoingreso;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            // Configurar la propiedad Anchor para cada control en el constructor del formulario
            loginButton.Anchor = AnchorStyles.Top | AnchorStyles.None;
            btncrea.Anchor = AnchorStyles.Top | AnchorStyles.None;
            jPassClave.Anchor = AnchorStyles.Top | AnchorStyles.None;
            jTxtUsuario.Anchor = AnchorStyles.Top | AnchorStyles.None;
            //this.Width = 685;  // Ancho en píxeles
            //this.Height = 490; // Alto en píxeles
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = ""; // Establecer el texto del formulario como una cadena vacía
        }
        



        // Evento para el botón de inicio de sesión
        private void loginButton_Click(object sender, EventArgs e)
        {
            // Obtener el correo electrónico del usuario y asignarlo a la propiedad UsuarioEmail
            UsuarioEmail = jTxtUsuario.Text;
            string email = jTxtUsuario.Text;
            string contraseña = jPassClave.Text;

            CConexion conexion = new CConexion();

            string numeroIdentificacion = conexion.VerificarCredenciales(email, contraseña);

            if (!string.IsNullOrEmpty(numeroIdentificacion))
            {
                // Establecer el email del usuario en la clase CConexion
                CConexion.EmailUsuario = email;

                // Cadena de conexión a la base de datos
                string servidor = "localhost";
                string bd = "pp";
                string usuario = "prueba";
                string password = "12345";
                string puerto = "1433";

                string miConnectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

                // Abrir el formulario Form2 y pasar la cadena de conexión al constructor
                Form2 form2 = new Form2(numeroIdentificacion, email, miConnectionString);
                form2.StartPosition = FormStartPosition.CenterScreen;
                form2.Show();
                this.Hide();

                // Abrir el formulario MiPerfilForm
                MiPerfilForm miPerfilForm = new MiPerfilForm(numeroIdentificacion, email);
                miPerfilForm.StartPosition = FormStartPosition.CenterScreen;
                //miPerfilForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Credenciales incorrectas. Inténtalo de nuevo.", "Error de inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            jTxtUsuario.Text = "Ingrese usuario";
            jTxtUsuario.ForeColor = Color.Gray;

            jPassClave.Text = "Ingrese contraseña";
            jPassClave.ForeColor = Color.Gray;
            jPassClave.PasswordChar = '\0'; // Eliminar el carácter de contraseña para mostrar el texto de marcador de posición
                                            // linkOlvidasteContraseña.LinkClicked += linkOlvidasteContraseña_LinkClicked_1;
            
        }

        private void jTxtUsuario_Enter(object sender, EventArgs e)
        {
            if (jTxtUsuario.Text == "Ingrese usuario")
            {
                jTxtUsuario.Text = "";
                jTxtUsuario.ForeColor = Color.Black;
            }
        }

        private void jTxtUsuario_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(jTxtUsuario.Text) || jTxtUsuario.Text == "Ingrese usuario")
            {
                jTxtUsuario.Text = "Ingrese usuario";
                jTxtUsuario.ForeColor = Color.Gray;
            }
        }

        private void jPassClave_Enter(object sender, EventArgs e)
        {
            if (jPassClave.Text == "Ingrese contraseña")
            {
                jPassClave.Text = "";
                jPassClave.ForeColor = Color.Black;
                jPassClave.PasswordChar = '*'; // Restaurar el carácter de contraseña si se eliminó
            }
        }

        private void jPassClave_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(jPassClave.Text))
            {
                jPassClave.Text = "Ingrese contraseña";
                jPassClave.ForeColor = Color.Gray;
                jPassClave.PasswordChar = '\0'; // Eliminar el carácter de contraseña para mostrar el texto de marcador de posición
            }
        }

        private void linkOlvidasteContraseña_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RecuperarClaveForm formRecuperarContraseña = new RecuperarClaveForm();
            formRecuperarContraseña.StartPosition = FormStartPosition.CenterScreen;
            formRecuperarContraseña.Show();
            this.Hide();
        }

        private void btncrea_Click_1(object sender, EventArgs e)
        {
            CrearCuentaForm crearCuentaForm = new CrearCuentaForm();
            crearCuentaForm.StartPosition = FormStartPosition.CenterScreen;
            crearCuentaForm.Show();
            this.Hide();
        }
    }
}






