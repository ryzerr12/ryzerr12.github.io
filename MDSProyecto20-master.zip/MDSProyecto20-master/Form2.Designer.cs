﻿namespace MDSProyecto
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.listFoto = new System.Windows.Forms.ListView();
            this.imageListP = new System.Windows.Forms.ImageList(this.components);
            this.btnUsuarioEs = new System.Windows.Forms.Button();
            this.AgendaSer = new System.Windows.Forms.Button();
            this.btnCotizar = new System.Windows.Forms.Button();
            this.btnEntregado = new System.Windows.Forms.Button();
            this.btnEnCamino = new System.Windows.Forms.Button();
            this.btnEnProceso = new System.Windows.Forms.Button();
            this.btnAbrirList = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnIniciarPro = new System.Windows.Forms.Button();
            this.btnInforme = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // listFoto
            // 
            this.listFoto.BackColor = System.Drawing.SystemColors.InfoText;
            this.listFoto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listFoto.ForeColor = System.Drawing.Color.White;
            this.listFoto.HideSelection = false;
            this.listFoto.LargeImageList = this.imageListP;
            this.listFoto.Location = new System.Drawing.Point(12, 164);
            this.listFoto.Name = "listFoto";
            this.listFoto.Scrollable = false;
            this.listFoto.Size = new System.Drawing.Size(278, 470);
            this.listFoto.SmallImageList = this.imageListP;
            this.listFoto.TabIndex = 4;
            this.listFoto.UseCompatibleStateImageBehavior = false;
            this.listFoto.Visible = false;
            // 
            // imageListP
            // 
            this.imageListP.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListP.ImageStream")));
            this.imageListP.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListP.Images.SetKeyName(0, "ubicaA.png");
            this.imageListP.Images.SetKeyName(1, "tarjeA.png");
            this.imageListP.Images.SetKeyName(2, "llaveA.png");
            // 
            // btnUsuarioEs
            // 
            this.btnUsuarioEs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUsuarioEs.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUsuarioEs.Location = new System.Drawing.Point(1260, 26);
            this.btnUsuarioEs.Name = "btnUsuarioEs";
            this.btnUsuarioEs.Size = new System.Drawing.Size(297, 52);
            this.btnUsuarioEs.TabIndex = 10;
            this.btnUsuarioEs.UseVisualStyleBackColor = true;
            this.btnUsuarioEs.Click += new System.EventHandler(this.textBoxUsuarioEs_Click);
            // 
            // AgendaSer
            // 
            this.AgendaSer.BackColor = System.Drawing.Color.Black;
            this.AgendaSer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgendaSer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.AgendaSer.Location = new System.Drawing.Point(427, 25);
            this.AgendaSer.Name = "AgendaSer";
            this.AgendaSer.Size = new System.Drawing.Size(204, 54);
            this.AgendaSer.TabIndex = 12;
            this.AgendaSer.Text = "Agendar servicio";
            this.AgendaSer.UseVisualStyleBackColor = false;
            this.AgendaSer.Click += new System.EventHandler(this.AgendaSer_Click);
            // 
            // btnCotizar
            // 
            this.btnCotizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCotizar.BackColor = System.Drawing.Color.Black;
            this.btnCotizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCotizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCotizar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.btnCotizar.Image = global::MDSProyecto.Properties.Resources._001;
            this.btnCotizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCotizar.Location = new System.Drawing.Point(1023, 24);
            this.btnCotizar.Name = "btnCotizar";
            this.btnCotizar.Size = new System.Drawing.Size(204, 52);
            this.btnCotizar.TabIndex = 11;
            this.btnCotizar.Text = "      Cotizador";
            this.btnCotizar.UseVisualStyleBackColor = false;
            this.btnCotizar.Click += new System.EventHandler(this.btnCotizar_Click);
            // 
            // btnEntregado
            // 
            this.btnEntregado.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEntregado.BackColor = System.Drawing.Color.White;
            this.btnEntregado.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnEntregado.FlatAppearance.BorderSize = 3;
            this.btnEntregado.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnEntregado.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnEntregado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntregado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEntregado.Image = global::MDSProyecto.Properties.Resources.repa;
            this.btnEntregado.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEntregado.Location = new System.Drawing.Point(1240, 494);
            this.btnEntregado.Name = "btnEntregado";
            this.btnEntregado.Size = new System.Drawing.Size(385, 341);
            this.btnEntregado.TabIndex = 7;
            this.btnEntregado.Text = "Entregado";
            this.btnEntregado.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEntregado.UseVisualStyleBackColor = false;
            this.btnEntregado.Click += new System.EventHandler(this.btnEntregado_Click);
            this.btnEntregado.Enter += new System.EventHandler(this.btnEntregado_MouseEnter);
            this.btnEntregado.Leave += new System.EventHandler(this.btnEntregado_MouseLeave);
            // 
            // btnEnCamino
            // 
            this.btnEnCamino.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEnCamino.AutoSize = true;
            this.btnEnCamino.BackColor = System.Drawing.Color.White;
            this.btnEnCamino.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnEnCamino.FlatAppearance.BorderSize = 3;
            this.btnEnCamino.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnEnCamino.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnEnCamino.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnCamino.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnCamino.Image = global::MDSProyecto.Properties.Resources.camio;
            this.btnEnCamino.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEnCamino.Location = new System.Drawing.Point(802, 494);
            this.btnEnCamino.Name = "btnEnCamino";
            this.btnEnCamino.Size = new System.Drawing.Size(385, 341);
            this.btnEnCamino.TabIndex = 5;
            this.btnEnCamino.Text = "En Camino";
            this.btnEnCamino.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEnCamino.UseVisualStyleBackColor = false;
            this.btnEnCamino.Click += new System.EventHandler(this.btnEnCamino_Click);
            this.btnEnCamino.Enter += new System.EventHandler(this.btnEnCamino_MouseEnter);
            this.btnEnCamino.Leave += new System.EventHandler(this.btnEnCamino_MouseLeave);
            // 
            // btnEnProceso
            // 
            this.btnEnProceso.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEnProceso.BackColor = System.Drawing.Color.White;
            this.btnEnProceso.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnEnProceso.FlatAppearance.BorderSize = 3;
            this.btnEnProceso.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnEnProceso.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnEnProceso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnProceso.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnProceso.Image = global::MDSProyecto.Properties.Resources.caja1;
            this.btnEnProceso.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEnProceso.Location = new System.Drawing.Point(349, 494);
            this.btnEnProceso.Name = "btnEnProceso";
            this.btnEnProceso.Size = new System.Drawing.Size(385, 341);
            this.btnEnProceso.TabIndex = 6;
            this.btnEnProceso.Text = "En Proceso";
            this.btnEnProceso.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEnProceso.UseVisualStyleBackColor = false;
            this.btnEnProceso.Click += new System.EventHandler(this.btnEnProceso_Click);
            this.btnEnProceso.Enter += new System.EventHandler(this.btnEnProceso_MouseEnter);
            this.btnEnProceso.Leave += new System.EventHandler(this.btnEnProceso_MouseEnter);
            // 
            // btnAbrirList
            // 
            this.btnAbrirList.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAbrirList.Image = global::MDSProyecto.Properties.Resources.menu;
            this.btnAbrirList.Location = new System.Drawing.Point(12, 143);
            this.btnAbrirList.Name = "btnAbrirList";
            this.btnAbrirList.Size = new System.Drawing.Size(39, 35);
            this.btnAbrirList.TabIndex = 1;
            this.btnAbrirList.UseVisualStyleBackColor = true;
            this.btnAbrirList.Click += new System.EventHandler(this.btnAbrirVentana_Click);
            this.btnAbrirList.MouseLeave += new System.EventHandler(this.btnAbrirVentana_MouseLeave);
            this.btnAbrirList.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnAbrirVentana_MouseMove);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::MDSProyecto.Properties.Resources.BIENVENI;
            this.pictureBox1.Location = new System.Drawing.Point(-4, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1596, 1020);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // btnIniciarPro
            // 
            this.btnIniciarPro.BackColor = System.Drawing.Color.Black;
            this.btnIniciarPro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciarPro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.btnIniciarPro.Location = new System.Drawing.Point(684, 26);
            this.btnIniciarPro.Name = "btnIniciarPro";
            this.btnIniciarPro.Size = new System.Drawing.Size(190, 53);
            this.btnIniciarPro.TabIndex = 13;
            this.btnIniciarPro.Text = "Iniciar Envío";
            this.btnIniciarPro.UseVisualStyleBackColor = false;
            this.btnIniciarPro.Click += new System.EventHandler(this.btnIniciarPro_Click);
            // 
            // btnInforme
            // 
            this.btnInforme.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnInforme.BackColor = System.Drawing.Color.Black;
            this.btnInforme.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInforme.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.btnInforme.Location = new System.Drawing.Point(41, 836);
            this.btnInforme.Name = "btnInforme";
            this.btnInforme.Size = new System.Drawing.Size(278, 54);
            this.btnInforme.TabIndex = 14;
            this.btnInforme.Text = "Informe de Comenatrios";
            this.btnInforme.UseVisualStyleBackColor = false;
            this.btnInforme.Click += new System.EventHandler(this.btnInforme_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1590, 923);
            this.Controls.Add(this.btnInforme);
            this.Controls.Add(this.btnIniciarPro);
            this.Controls.Add(this.AgendaSer);
            this.Controls.Add(this.btnCotizar);
            this.Controls.Add(this.btnUsuarioEs);
            this.Controls.Add(this.btnEntregado);
            this.Controls.Add(this.btnEnCamino);
            this.Controls.Add(this.btnEnProceso);
            this.Controls.Add(this.listFoto);
            this.Controls.Add(this.btnAbrirList);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAbrirList;
        private System.Windows.Forms.ListView listFoto;
        private System.Windows.Forms.ImageList imageListP;
        private System.Windows.Forms.Button btnEnCamino;
        public System.Windows.Forms.Button btnEnProceso;
        private System.Windows.Forms.Button btnEntregado;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnUsuarioEs;
        private System.Windows.Forms.Button btnCotizar;
        private System.Windows.Forms.Button AgendaSer;
        private System.Windows.Forms.Button btnIniciarPro;
        private System.Windows.Forms.Button btnInforme;
    }
}
