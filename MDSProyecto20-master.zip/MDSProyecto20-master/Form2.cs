﻿using MDSProyecto.Properties;
using System;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using MDSProyecto;
using System.Data.SqlClient;



namespace MDSProyecto
{
    public partial class Form2 : Form
    {

        private string numeroIdentificacion;
        private string email;
 
        private int contadorServicios = 0; // Inicialmente el contador está en 0
        private string connectionString; // Variable para almacenar la cadena de conexión

        // Variable estática para almacenar el correo electrónico del usuario
        public static string EmailUsuario { get; set; }

        // Agregar la siguiente variable de clase para el temporizador
        private System.Windows.Forms.Timer timer;
        private int contadorEnProceso = 0;
        private int contadorEnCamino = 0;
        private int contadorEntregado = 0;
        public int contadorEliminados = 0; // Variable para almacenar la cantidad de servicios eliminados

        // Agregar el temporizador para el botón btnEnCamino
        private System.Windows.Forms.Timer timerEnCamino;
        
        public Form2(string numeroIdentificacion, string email, string connectionString)
        {
            InitializeComponent();
            this.numeroIdentificacion = numeroIdentificacion;
            this.email = email;

            this.connectionString = connectionString;

            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Agregar la suscripción al evento Load
            this.Load += Form2_Load;

            // Configurar el ListView
            listFoto.View = View.Tile;
            listFoto.TileSize = new Size(200, 80);
            listFoto.Font = new Font("Arial", 12, FontStyle.Bold);
            listFoto.BackColor = Color.Black;
            listFoto.ForeColor = Color.White;
            listFoto.Scrollable = false;

            // Agregar imágenes al ImageList
            imageListP.Images.Add(Properties.Resources.ubicaA); // Índice 0
            imageListP.Images.Add(Properties.Resources.tarjeA); // Índice 1
            imageListP.Images.Add(Properties.Resources.llaveA); // Índice 2

            // Agregar elementos al ListView
            listFoto.Items.Add(new ListViewItem("Direcciones", 0));
            listFoto.Items.Add(new ListViewItem("Mis tarjetas", 1));
            listFoto.Items.Add(new ListViewItem("Mi perfil", 2));

            // Agregar eventos
            listFoto.MouseDoubleClick += ListFoto_MouseDoubleClick;

            // Agregar eventos de los botones
            btnEnProceso.MouseEnter += btnEnProceso_MouseEnter;
            btnEnProceso.MouseLeave += btnEnProceso_MouseLeave;
            btnEnCamino.MouseEnter += btnEnCamino_MouseEnter;
            btnEnCamino.MouseLeave += btnEnCamino_MouseLeave;
            btnEntregado.MouseEnter += btnEntregado_MouseEnter;
            btnEntregado.MouseLeave += btnEntregado_MouseLeave;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            // Inicializar el temporizador y configurar su evento Tick
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 10000; // 10000 milisegundos = 10 segundos
            timer.Tick += Timer_Tick;

            // Inicializar el temporizador para el botón btnEnCamino y configurar su evento Tick
            timerEnCamino = new System.Windows.Forms.Timer();
            timerEnCamino.Interval = 10000; // 10000 milisegundos = 10 segundos
            timerEnCamino.Tick += TimerEnCamino_Tick;

        }
        
        private void ListFoto_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listFoto.SelectedItems.Count > 0)
            {
                string selectedItem = listFoto.SelectedItems[0].Text;

                // Realizar acciones según el elemento seleccionado
                if (selectedItem == "Direcciones")
                {
                    DireccionesForm direccionesForm = new DireccionesForm();
                    direccionesForm.StartPosition = FormStartPosition.CenterScreen; // Establecer el inicio del formulario en el centro de la pantalla
                    direccionesForm.Show();
                }
                else if (selectedItem == "Mis tarjetas")
                {
                    MisTarjetasForm misTarjetasForm = new MisTarjetasForm(EmailUsuario);
                    misTarjetasForm.StartPosition = FormStartPosition.CenterScreen; // Establecer el inicio del formulario en el centro de la pantalla
                    misTarjetasForm.Show();
                }
                else if (selectedItem == "Mi perfil")
                {
                    MiPerfilForm miPerfilForm = new MiPerfilForm(numeroIdentificacion, email);
                    miPerfilForm.StartPosition = FormStartPosition.CenterScreen; // Establecer el inicio del formulario en el centro de la pantalla
                    miPerfilForm.Show();
                }

                // Ocultar el ListView después de realizar la acción
                listFoto.Visible = false;
            }
        }

        private void btnAbrirVentana_Click(object sender, EventArgs e)
        {
            listFoto.Visible = true; // Mostrar el ListView cuando se hace clic en el botón
        }

        private void btnAbrirVentana_MouseMove(object sender, MouseEventArgs e)
        {
            listFoto.Visible = true; // Mostrar el ListView cuando el cursor se mueve sobre el botón
        }

        private void btnAbrirVentana_MouseLeave(object sender, EventArgs e)
        {
            if (!listFoto.ClientRectangle.Contains(listFoto.PointToClient(Control.MousePosition)))
            {
                listFoto.Visible = false; // Ocultar el ListView si el cursor se mueve fuera del botón y el ListView
            }
        }

        private void btnEnProceso_MouseEnter(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = Color.White;
            button.ForeColor = Color.Black;
        }

        private void btnEnProceso_MouseLeave(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.FlatAppearance.BorderSize = 1;
            button.BackColor = Color.White;
            button.ForeColor = Color.Black;
            //button.Location = new Point(button.Location.X, button.Location.Y - 2); // Vuelve a la ubicación original del botón
        }

        private void btnEnCamino_MouseEnter(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = Color.White;
            button.ForeColor = Color.Black;
            //button.Location = new Point(button.Location.X, button.Location.Y + 2); // Desplaza el botón hacia abajo para simular la sombra
        }

        private void btnEnCamino_MouseLeave(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.FlatAppearance.BorderSize = 1;
            button.BackColor = Color.White;
            button.ForeColor = Color.Black;
            //button.Location = new Point(button.Location.X, button.Location.Y - 2); // Vuelve a la ubicación original del botón
        }

        private void btnEntregado_MouseEnter(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = Color.White;
            button.ForeColor = Color.Black;
            //button.Location = new Point(button.Location.X, button.Location.Y + 2); // Desplaza el botón hacia abajo para simular la sombra
        }

        private void btnEntregado_MouseLeave(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.FlatAppearance.BorderSize = 1;
            button.BackColor = Color.White;
            button.ForeColor = Color.Black;
            //button.Location = new Point(button.Location.X, button.Location.Y - 2); // Vuelve a la ubicación original del botón
        }
        protected override void OnMove(EventArgs e)
        {
            // Restablecer la posición del formulario al centro de la pantalla en caso de que se intente mover
            this.Location = new Point((Screen.PrimaryScreen.Bounds.Width - this.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2);

            base.OnMove(e);
        }
        private void btnEnProceso_Click(object sender, EventArgs e)
        {
            string userEmail = btnUsuarioEs.Text;

            PendienteForm formularioPendiente = new PendienteForm(userEmail);
            formularioPendiente.StartPosition = FormStartPosition.CenterScreen;
            formularioPendiente.Show();

        }

        private void btnEnCamino_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Su Pedido esta en ! CAMINO ¡");
        }

        private void btnEntregado_Click(object sender, EventArgs e)
        {
            string userEmail = btnUsuarioEs.Text;

            EntregadoForm entregaForm = new EntregadoForm(userEmail);
            entregaForm.StartPosition = FormStartPosition.CenterScreen; // Establecer el inicio del formulario en el centro de la pantalla
            entregaForm.Show();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            // Resto del código del evento Load

            // Asignar el email al botón
            btnUsuarioEs.Text = email;

            // Asignar el correo electrónico del usuario a la propiedad estática EmailUsuario
            EmailUsuario = email;

           
        }

        private void btnAbrirMisTarjetas_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCotizar_Click(object sender, EventArgs e)
        {
            // Crear una instancia del formulario Cotizador.cs
            Cotizador formularioCotizar = new Cotizador();

            // Mostrar el formulario Cotizador.cs
            formularioCotizar.Show();
        }


        public int contadorEli;
        // Método para actualizar el contador según el usuario
        public void ActualizarContador(int contadorEliminados)
        {
            contadorEli = contadorEliminados;
            btnEnProceso.Text = "En Proceso (" + contadorEliminados.ToString() + ")";
            btnEnProceso.Refresh(); // Forzar actualización visual del botón

            // Si el contador de eliminados está en 1 o más y el temporizador no está en marcha, activar el temporizador
            if (contadorEliminados >= 1 && !timer.Enabled)
            {
                if (timer == null)
                {
                    timer = new System.Windows.Forms.Timer();
                    timer.Interval = 10000; // 10000 milisegundos = 10 segundos
                    timer.Tick += Timer_Tick;
                }

                timer.Start();
            }
        }

    public int contarpipipi;
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Detener el temporizador
            timer.Stop();

            // Mover el contador a btnEnCamino
            contadorEnCamino += contadorEli;
            int contarsisi = contadorEli;
            btnEnCamino.Text = "En Camino (" + contarsisi.ToString() + ")";
            contarpipipi = contadorEnCamino;
            // Reiniciar el contador y actualizar el botón btnEnProceso
            contadorEliminados = 0;
            btnEnProceso.Text = "En Proceso (" + contadorEliminados.ToString() + ")";

            // Si el contadorEnCamino está en 1 o más y el temporizador del botón btnEntregado no está en marcha, activar el temporizador del botón btnEntregado
            if (contadorEli >= 1 && !timerEnCamino.Enabled)
            {
                timerEnCamino.Start();
            }
        }

        private void TimerEnCamino_Tick(object sender, EventArgs e)
        {
            // Detener el temporizador del botón btnEnCamino
            timerEnCamino.Stop();

            // Mover el contador a btnEntregado
            contadorEntregado += contadorEnCamino;
            int contarjojo = contadorEnCamino;
            btnEntregado.Text = "Entregado (" + contarjojo.ToString() + ")";

            // Reiniciar el contador de btnEnCamino
            contadorEliminados = 0;
            btnEnCamino.Text = "En Camino (" + contadorEliminados.ToString() + ")";
        }


        // Método que se ejecutará cuando se agregue un nuevo servicio en AgendaServicio.cs
        private void AgendaServicioForm_ServicioAgregado(object sender, EventArgs e)
        {
            // Actualizar el contador de servicios cuando se agregue un nuevo servicio
            ActualizarContador(contadorEliminados);
        }

        private void AgendaSer_Click(object sender, EventArgs e)
        {
            {
                string userEmail = btnUsuarioEs.Text; // Obtener el valor del correo electrónico del TextBox

                // Abrir el formulario AgendaServicio y pasar el correo electrónico como argumento
                AgendaServicio agendaServicioForm = new AgendaServicio(userEmail);
                agendaServicioForm.Show();
            }
        }

        private void textBoxUsuarioEs_Click(object sender, EventArgs e)
        {
            // Obtener el correo electrónico del titular desde textBoxUsuarioEs
            EmailUsuario = btnUsuarioEs.Text;
        }

        private void btnIniciarPro_Click(object sender, EventArgs e)
        {
            {
                string userEmail = btnUsuarioEs.Text; // Obtener el valor del correo electrónico del TextBox

                // Abrir el formulario AgendaServicio y pasar el correo electrónico como argumento
                IniciarPro formularioIniciarPro = new IniciarPro(userEmail);
                formularioIniciarPro.Show();
            }
        }

        private void btnInforme_Click(object sender, EventArgs e)
        {
            InformeComentariosForm informeForm = new InformeComentariosForm();
            informeForm.Show();
        }

    }
}




