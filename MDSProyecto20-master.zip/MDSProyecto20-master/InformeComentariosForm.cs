﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using MDSProyecto.Clases; // Agrega esta línea para importar el espacio de nombres que contiene la clase Comentario

namespace MDSProyecto
{
    public partial class InformeComentariosForm : Form
    {
        public InformeComentariosForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void btnGenerarInforme_Click(object sender, EventArgs e)
        {
            DateTime fechaSeleccionada = dateTimePickerFecha.Value;

            // Llama al método en CConexion para obtener los comentarios filtrados por la fecha
            List<CConexion.Comentario> comentariosFiltrados = CConexion.ObtenerComentariosPorFecha(fechaSeleccionada);

            // Luego, crea un formulario o reporte para mostrar los comentarios filtrados en un archivo PDF
            // En este ejemplo, crearemos un informe en PDF utilizando la librería iTextSharp
            GuardarPDF(comentariosFiltrados, fechaSeleccionada);
        }

        private void GuardarPDF(List<CConexion.Comentario> comentarios, DateTime fecha)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivo PDF|*.pdf";
            saveFileDialog.Title = "Guardar informe como PDF";
            saveFileDialog.FileName = $"InformeComentarios_{fecha.ToString("yyyyMMdd")}.pdf";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string nombreArchivo = saveFileDialog.FileName;

                // Crear el documento PDF
                using (Document document = new Document(PageSize.A4))
                {
                    // Crear el archivo PDF en la ruta seleccionada por el usuario
                    using (FileStream fs = new FileStream(nombreArchivo, FileMode.Create))
                    {
                        PdfWriter.GetInstance(document, fs);

                        // Abrir el documento
                        document.Open();

                        // Agregar título e información sobre la fecha
                        Paragraph titulo = new Paragraph($"Informe de Comentarios - {fecha.ToString("dd/MM/yyyy")}", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18f));
                        titulo.Alignment = Element.ALIGN_CENTER;
                        document.Add(titulo);

                        // Agregar un párrafo vacío para crear espacio entre el título y la tabla
                        Paragraph espacio = new Paragraph(" "); // Puedes ajustar la cantidad de espacios en blanco según la separación deseada
                        document.Add(espacio);

                        // Agregar los comentarios al documento
                        PdfPTable tablaComentarios = new PdfPTable(2); // 2 columnas para Usuario y Comentario

                        // Ajustar el ancho de las columnas de la tabla
                        float[] columnWidths = { 30f, 100f };
                        tablaComentarios.SetWidths(columnWidths);

                        // Estilo para los títulos del encabezado (negrilla)
                        var estiloTitulo = FontFactory.GetFont(FontFactory.HELVETICA_BOLD);

                        // Encabezado de la tabla
                        PdfPCell celdaUsuario = new PdfPCell(new Phrase("Usuario", estiloTitulo));
                        celdaUsuario.HorizontalAlignment = Element.ALIGN_CENTER;
                        celdaUsuario.VerticalAlignment = Element.ALIGN_MIDDLE;
                        tablaComentarios.AddCell(celdaUsuario);

                        PdfPCell celdaComentario = new PdfPCell(new Phrase("Comentario", estiloTitulo));
                        celdaComentario.HorizontalAlignment = Element.ALIGN_CENTER;
                        celdaComentario.VerticalAlignment = Element.ALIGN_MIDDLE;
                        tablaComentarios.AddCell(celdaComentario);

                        // Agregar los comentarios a la tabla
                        foreach (CConexion.Comentario comentario in comentarios)
                        {
                            PdfPCell celdaUsuarioContenido = new PdfPCell(new Phrase(comentario.UsuarioEmail));
                            celdaUsuarioContenido.HorizontalAlignment = Element.ALIGN_LEFT;
                            celdaUsuarioContenido.VerticalAlignment = Element.ALIGN_MIDDLE;
                            tablaComentarios.AddCell(celdaUsuarioContenido);

                            PdfPCell celdaComentarioContenido = new PdfPCell(new Phrase(comentario.Contenido));
                            celdaComentarioContenido.HorizontalAlignment = Element.ALIGN_LEFT;
                            celdaComentarioContenido.VerticalAlignment = Element.ALIGN_MIDDLE;
                            tablaComentarios.AddCell(celdaComentarioContenido);
                        }

                        // Agregar la tabla al documento
                        document.Add(tablaComentarios);

                        // Cerrar el documento
                        document.Close();
                    }
                }

                // Mostrar mensaje de confirmación al usuario
                MessageBox.Show($"Informe generado correctamente. Puedes encontrarlo en el archivo: {nombreArchivo}", "Informe generado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Cerrar el formulario actual
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
