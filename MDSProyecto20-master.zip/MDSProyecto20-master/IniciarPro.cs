﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using MDSProyecto;

namespace MDSProyecto
{
    public partial class IniciarPro : Form
    {

        private string userEmail;
        private string connectionString;
        
        public delegate void ProcesoFinalizadoEventHandler(object sender, EventArgs e);
        public event ProcesoFinalizadoEventHandler ProcesoFinalizado;

        // Declarar el evento ServicioAgregado en la clase AgregarServicio
        public event EventHandler ServicioAgregado;

        
        public IniciarPro(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail;

            string servidor = "localhost";
            string bd = "pp";
            string usuario = "prueba";
            string password = "12345";
            string puerto = "1433";

            connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

            // Configurar el DateTimePicker para mostrar solo el selector de hora
            dateTimePickerHora.Format = DateTimePickerFormat.Time;
            dateTimePickerHora.ShowUpDown = true;

            // Establecer un valor inicial para la hora seleccionada (opcional)
            dateTimePickerHora.Value = DateTime.Now; // Puedes cambiar DateTime.Now por la hora que desees

            // Restricción opcional: Establecer un rango de horas permitidas
            dateTimePickerHora.MinDate = DateTime.Today.AddHours(4); // Por ejemplo, 8:00 AM
            dateTimePickerHora.MaxDate = DateTime.Today.AddHours(21); // Por ejemplo, 5:00 PM

            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

        }
        
        private void btnGuardarR_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Obtener los IDs ingresados en el TextBox
                    string[] idsAEliminar = txtBoxID.Text.Split(',');
                    int contadorEliminados = 0;
                    // Suponiendo que tienes una conexión a la base de datos llamada "connectionString"
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        foreach (string idAEliminar in idsAEliminar)
                        {
                            if (int.TryParse(idAEliminar, out int idServicioAEliminar))
                            {
                                // Verificar si el ID existe en la tabla AgendaServicio
                                string checkQuery = "SELECT COUNT(*) FROM AgendaServicio WHERE ID = @IDServicio";
                                using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                                {
                                    checkCommand.Parameters.AddWithValue("@IDServicio", idServicioAEliminar);

                                    int exists = (int)checkCommand.ExecuteScalar();

                                    if (exists > 0)
                                    {
                                        // Preparar el comando SQL para transferir el registro de AgendaServicio a TablaDestino
                                        string transferQuery = "INSERT INTO TablaDestino (ProEnviar, PesoKg, ValorUni, Cantidad, Fecha, Hora, EnvioExp, UsuarioEmail, Ancho, Alto, Largo) " +
                                                                "SELECT ProEnviar, PesoKg, ValorUni, Cantidad, Fecha, Hora, EnvioExp, UsuarioEmail, Ancho, Alto, Largo " +
                                                                "FROM AgendaServicio WHERE ID = @IDServicio";
                                        using (SqlCommand transferCommand = new SqlCommand(transferQuery, connection))
                                        {
                                            transferCommand.Parameters.AddWithValue("@IDServicio", idServicioAEliminar);
                                            transferCommand.ExecuteNonQuery();
                                        }

                                        // Preparar el comando SQL para eliminar el registro de la base de datos
                                        string deleteQuery = "DELETE FROM AgendaServicio WHERE ID = @IDServicio";
                                        using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                                        {
                                            deleteCommand.Parameters.AddWithValue("@IDServicio", idServicioAEliminar);
                                            deleteCommand.ExecuteNonQuery();
                                        }

                                        contadorEliminados++;
                                    }
                                    else
                                    {
                                        // Mostrar un mensaje indicando que el ID no existe en la tabla AgendaServicio
                                        MessageBox.Show($"El ID {idServicioAEliminar} no existe en la tabla AgendaServicio.", "ID no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                }
                            }
                        }
                    }


                    // Mostrar el mensaje de éxito aquí, antes de cerrar el formulario
                    MessageBox.Show($"Su paquete esta en proceso {contadorEliminados} .");
                    // Obtener una referencia al formulario Form2.cs
                    int numero = contadorEliminados;
                    Form2 form2 = Application.OpenForms.OfType<Form2>().FirstOrDefault();

                    if (form2 != null)
                    {
                        // Pasar el parámetro userEmail al método ActualizarContador
                        form2.ActualizarContador(numero); // Supongo que userEmail es el correo del usuario actual
                    }

                    // Cerrar el formulario IniciarPro.cs
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
    }


