﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace MDSProyecto
{
    public partial class AgendaServicio : Form
    {
        

        // Declarar el evento ServicioAgregado en la clase AgregarServicio
        public event EventHandler ServicioAgregado;

        private string userEmail;
        private string connectionString;

        public AgendaServicio(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail;

            string servidor = "localhost";
            string bd = "pp";
            string usuario = "prueba";
            string password = "12345";
            string puerto = "1433";

            connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

            this.ClientSize = new System.Drawing.Size(pictureBox1.Width, pictureBox1.Height);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Suscribir al evento KeyPress para los TextBox que requieren valores numéricos
            PesoKg.KeyPress += TextBox_KeyPress;
            Alto.KeyPress += TextBox_KeyPress;
            Ancho.KeyPress += TextBox_KeyPress;
            ValorUni.KeyPress += TextBox_KeyPress;
            Cantidad.KeyPress += TextBox_KeyPress;

            // Asignar eventos Validating a los TextBox
            PesoKg.Validating += PesoKg_Validating;
            Ancho.Validating += Ancho_Validating;
            Largo.Validating += Largo_Validating;
            Alto.Validating += Alto_Validating;
        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números y el carácter de separador decimal (punto)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }

            // Permitir solo un separador decimal (punto)
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }
        private void PesoKg_Validating(object sender, CancelEventArgs e)
        {
            if (decimal.TryParse(PesoKg.Text, out decimal peso))
            {
                if (peso < 50 || peso > 1400)
                {
                    e.Cancel = true;
                    PesoKg.Select(0, PesoKg.Text.Length);
                    errorProvider.SetError(PesoKg, "El peso debe estar entre 50 y 1400 (Kg).");
                }
                else
                {
                    errorProvider.SetError(PesoKg, "");
                }
            }
            else
            {
                e.Cancel = true;
                PesoKg.Select(0, PesoKg.Text.Length);
                errorProvider.SetError(PesoKg, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void Ancho_Validating(object sender, CancelEventArgs e)
        {
            if (int.TryParse(Ancho.Text, out int ancho))
            {
                if (ancho < 0 || ancho > 214)
                {
                    e.Cancel = true;
                    Ancho.Select(0, Ancho.Text.Length);
                    errorProvider.SetError(Ancho, "El ancho debe estar entre 0 y 214.");
                }
                else
                {
                    errorProvider.SetError(Ancho, "");
                }
            }
            else
            {
                e.Cancel = true;
                Ancho.Select(0, Ancho.Text.Length);
                errorProvider.SetError(Ancho, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void Largo_Validating(object sender, CancelEventArgs e)
        {
            if (int.TryParse(Largo.Text, out int largo))
            {
                if (largo < 0 || largo > 434)
                {
                    e.Cancel = true;
                    Largo.Select(0, Largo.Text.Length);
                    errorProvider.SetError(Largo, "El largo debe estar entre 0 y 434.");
                }
                else
                {
                    errorProvider.SetError(Largo, "");
                }
            }
            else
            {
                e.Cancel = true;
                Largo.Select(0, Largo.Text.Length);
                errorProvider.SetError(Largo, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void Alto_Validating(object sender, CancelEventArgs e)
        {
            if (int.TryParse(Alto.Text, out int alto))
            {
                if (alto < 0 || alto > 225)
                {
                    e.Cancel = true;
                    Alto.Select(0, Alto.Text.Length);
                    errorProvider.SetError(Alto, "El alto debe estar entre 0 y 225.");
                }
                else
                {
                    errorProvider.SetError(Alto, "");
                }
            }
            else
            {
                e.Cancel = true;
                Alto.Select(0, Alto.Text.Length);
                errorProvider.SetError(Alto, "Por favor, ingresa un valor numérico válido.");
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los TextBox
                string proEnviar = ProEnviar.Text;
                decimal pesoKg;
                int alto;
                int ancho;
                decimal valorUni;
                int cantidad;
                decimal largo;

                if (!decimal.TryParse(PesoKg.Text, out pesoKg) ||
                    !decimal.TryParse(Largo.Text, out largo) ||
                    !int.TryParse(Alto.Text, out alto) ||
                    !int.TryParse(Ancho.Text, out ancho) ||
                    !decimal.TryParse(ValorUni.Text, out valorUni) ||
                    !int.TryParse(Cantidad.Text, out cantidad))
                {
                    throw new FormatException();
                }

                // Obtener la fecha y hora seleccionadas por el usuario en el DateTimePicker dateTimePickerFechaHora
                DateTime fechaHora = dateTimePickerFechaHora.Value;

                // Extraer la fecha y la hora por separado, si lo necesitas
                DateTime fecha = fechaHora.Date;
                TimeSpan hora = fechaHora.TimeOfDay;

                // Obtener el valor seleccionado del RadioButton dentro del GroupBox
                bool envioExp = radioButtonSi.Checked; // Si el RadioButton "Sí" está seleccionado, envioExp será true; de lo contrario, será false.

                // Insertar los datos en la base de datos
                string consultaInsertar = "INSERT INTO AgendaServicio (ProEnviar, PesoKg, Ancho, Alto, Largo, ValorUni, Cantidad, Fecha, Hora, EnvioExp, UsuarioEmail) " +
                                          "VALUES (@ProEnviar, @PesoKg, @Ancho, @Alto, @Largo, @ValorUni, @Cantidad, @Fecha, @Hora, @EnvioExp, @UsuarioEmail)";

                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    using (SqlCommand comandoInsertar = new SqlCommand(consultaInsertar, conexion))
                    {
                        comandoInsertar.Parameters.AddWithValue("@ProEnviar", proEnviar);
                        comandoInsertar.Parameters.AddWithValue("@PesoKg", pesoKg);
                        comandoInsertar.Parameters.AddWithValue("@Alto", alto);
                        comandoInsertar.Parameters.AddWithValue("@Ancho", ancho);
                        comandoInsertar.Parameters.AddWithValue("@Largo", largo);
                        comandoInsertar.Parameters.AddWithValue("@ValorUni", valorUni);
                        comandoInsertar.Parameters.AddWithValue("@Cantidad", cantidad);
                        comandoInsertar.Parameters.AddWithValue("@Fecha", fecha);
                        comandoInsertar.Parameters.AddWithValue("@Hora", hora);
                        comandoInsertar.Parameters.AddWithValue("@EnvioExp", envioExp);
                        comandoInsertar.Parameters.AddWithValue("@UsuarioEmail", userEmail);

                        conexion.Open();
                        comandoInsertar.ExecuteNonQuery();
                        conexion.Close();

                        // Obtener una referencia al formulario Form2.cs
                        Form2 form2 = Application.OpenForms.OfType<Form2>().FirstOrDefault();

                        if (form2 != null)
                        {
                            // Incrementar el contador del formulario Form2.cs
                            form2.ActualizarContador(userEmail);

                            // Actualizar el contador en la base de datos
                            string consultaActualizarContador = "UPDATE ContadorPorCliente SET Contador = Contador + 1 WHERE EmailCliente = @EmailCliente";
                            using (SqlCommand comandoActualizarContador = new SqlCommand(consultaActualizarContador, conexion))
                            {
                                comandoActualizarContador.Parameters.AddWithValue("@EmailCliente", userEmail);
                                conexion.Open();
                                comandoActualizarContador.ExecuteNonQuery();
                            }
                        }

                        // Notificar al Form2.cs que se ha agregado un nuevo servicio
                        OnServicioAgregado();

                        MessageBox.Show("Datos guardados exitosamente en la base de datos.");
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingresa valores numéricos válidos para PesoKg, Alto, Ancho, ValorUni y Cantidad.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        // Método para invocar el evento ServicioAgregado
        protected virtual void OnServicioAgregado()
        {
            ServicioAgregado?.Invoke(this, EventArgs.Empty);
        }




        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
