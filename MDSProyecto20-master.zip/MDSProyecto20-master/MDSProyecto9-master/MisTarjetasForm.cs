﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MDSProyecto.Clases;

namespace MDSProyecto
{
    public partial class MisTarjetasForm : Form
    {
        private string emailUsuario;
        // Variable global para almacenar el email del usuario
        private string emailUsuarioGlobal;
        public MisTarjetasForm(string emailUsuario)
        {
            InitializeComponent();
            this.emailUsuario = emailUsuario;
            // Cargar las tarjetas al iniciar el formulario
            CargarTarjetas();
            
            this.Text = ""; // Establecer el texto del formulario como una cadena vacía
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            // Asigna el email del usuario recibido como argumento a la variable global
            emailUsuarioGlobal = emailUsuario;
            // Deshabilitar botones de minimizar y maximizar
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Deshabilitar el control box (botones de cerrar y barra de título)
            this.ControlBox = false;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            

        }
        // Método para obtener el email del usuario actual
        private string ObtenerEmailUsuario()
        {
            // Devuelve el email almacenado en la variable global
            return emailUsuarioGlobal;
        }
        private void CargarTarjetas()
        {
            // Obtener los datos de las tarjetas desde la base de datos para el usuario actual
            CConexion conexion = new CConexion();
            DataTable tarjetas = conexion.ObtenerTarjetasPorUsuario(emailUsuario); // Método para obtener los datos de las tarjetas filtradas por usuario

            // Mostrar los datos en el DataGridView
            dataGridViewTarjetas.DataSource = tarjetas;
        }




        private void btnRegTarjeta_Click_1(object sender, EventArgs e)
        {
            // Cerrar el formulario actual
            this.Close();

            // Supongamos que aquí obtienes el valor de emailUsuario (puedes reemplazarlo por tu forma de obtener el email del usuario)
            string emailUsuario = ObtenerEmailUsuario();

            // Pasar el email del usuario como argumento al crear el formulario RegistrarTarjetaForm
            RegistrarTarjetaForm registrarTarjetaForm = new RegistrarTarjetaForm(emailUsuario);
            registrarTarjetaForm.StartPosition = FormStartPosition.CenterScreen;
            registrarTarjetaForm.ShowDialog();
        }
        
        protected override void OnMove(EventArgs e)
        {
            // Restablecer la posición del formulario al centro de la pantalla en caso de que se intente mover
            this.Location = new Point((Screen.PrimaryScreen.Bounds.Width - this.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2);

            base.OnMove(e);
        }

        private void MisTarjetasForm_Load(object sender, EventArgs e)
        {
            // Deshabilitar el ajuste automático de las columnas para evitar que se ajusten automáticamente al tamaño del contenido
            dataGridViewTarjetas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            // Deshabilitar el redimensionamiento de las columnas
            foreach (DataGridViewColumn column in dataGridViewTarjetas.Columns)
            {
                column.Resizable = DataGridViewTriState.False;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridViewTarjetas.SelectedRows.Count > 0)
            {
                try
                {
                    // Obtener el email del usuario actual (supongamos que tienes el email almacenado en una variable llamada "emailUsuario")
                    string emailUsuario = ObtenerEmailUsuario(); // Debes implementar el método para obtener el email del usuario

                    // Crear una instancia de la clase CConexion
                    CConexion conexion = new CConexion();

                    // Llamar al método para eliminar el registro de la base de datos basado en el email del usuario
                    conexion.EliminarRegistroPorEmail(emailUsuario);

                    // Eliminar la fila seleccionada del DataGridView
                    dataGridViewTarjetas.Rows.RemoveAt(dataGridViewTarjetas.SelectedRows[0].Index);

                    // Mostrar mensaje de confirmación
                    MessageBox.Show("Registro eliminado correctamente.", "Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // Mostrar mensaje de error si ocurrió un problema al eliminar el registro
                    MessageBox.Show("Error al eliminar el registro: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Mostrar mensaje si no se seleccionó ninguna fila para eliminar
                MessageBox.Show("Por favor, seleccione una fila para eliminar.", "Sin selección", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}


