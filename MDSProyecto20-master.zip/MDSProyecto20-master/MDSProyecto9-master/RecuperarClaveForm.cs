﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class RecuperarClaveForm : Form
    {
        public RecuperarClaveForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen; // Centrar el formulario en la pantalla
            this.Load += RecuperarClaveForm_Load;
            this.ControlBox = false;
            this.Text = ""; // Establecer el texto del formulario como una cadena vacía
        }

        private void RecuperarClaveForm_Load(object sender, EventArgs e)
        {
            //this.StartPosition = FormStartPosition.CenterScreen; // Establecer la posición de inicio en el centro de la pantalla
        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            string numeroIdentificacion = txtNumeroIdentificacion.Text;
            string nuevaContraseña = txtNuevaContraseña.Text;
            string confirmarContraseña = txtConfirmarContraseña.Text;

            if (string.IsNullOrEmpty(numeroIdentificacion) || string.IsNullOrEmpty(nuevaContraseña) || string.IsNullOrEmpty(confirmarContraseña))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            if (nuevaContraseña != confirmarContraseña)
            {
                MessageBox.Show("La nueva contraseña y la confirmación no coinciden.");
                return;
            }

            Clases.CConexion conexion = new Clases.CConexion();

            // Actualizar la contraseña en la base de datos
            if (conexion.ActualizarContraseña(numeroIdentificacion, nuevaContraseña))
            {
                MessageBox.Show("La contraseña se actualizó correctamente.");

                // Cerrar la instancia actual de RecuperarClaveForm y mostrar la instancia existente de Form1
                this.Close();
                Form1.Instance.Show();
            }
            else
            {
                MessageBox.Show("No se pudo actualizar la contraseña. Por favor, inténtelo nuevamente.");
            }
        }

        

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1.Instance.WindowState = FormWindowState.Normal; // Restaurar el formulario Form1 si estaba minimizado
            Form1.Instance.Show(); // Mostrar el formulario Form1
            this.Hide(); // Ocultar el formulario actual (RecuperarClaveForm)
        }
        

    }
}

