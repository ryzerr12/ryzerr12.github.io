﻿using MDSProyecto.Clases;
using MDSProyecto.Properties;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class RegistrarTarjetaForm : Form
    {
        private string emailUsuario;
        // Propiedad para almacenar el email del usuario
        private string EmailUsuario { get; }
        public RegistrarTarjetaForm(string emailUsuario)
        {
            InitializeComponent();

            jTxtNumeroT.TextChanged += jTxtNumeroT_TextChanged;
            jTxtNumeroT.KeyPress += jTxtNumeroT_KeyPress;
            jTxtAño.KeyPress += jTxtAño_KeyPress;
            jTxtMes.KeyPress += jTxtMes_KeyPress;
            jTxtAño.TextChanged += jTxtAño_TextChanged;
            jTxtMes.TextChanged += jTxtMes_TextChanged;
            jTxtNomTitular.TextChanged += jTxtNomTitular_TextChanged;
            jTxtCVV.TextChanged += jTxtCVV_TextChanged;

            pictureBoxT.SizeMode = PictureBoxSizeMode.StretchImage;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Restablecer el tamaño del formulario
            this.ClientSize = new Size(420, 515); // Ajusta el tamaño según tus necesidades

            this.emailUsuario = emailUsuario;
            // Almacena el email del usuario en la propiedad EmailUsuario
            EmailUsuario = emailUsuario;

            // Deshabilitar botones de minimizar y maximizar
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Deshabilitar el control box (botones de cerrar y barra de título)
            this.ControlBox = false;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            
        }
        protected override void OnMove(EventArgs e)
        {
            // Restablecer la posición del formulario al centro de la pantalla en caso de que se intente mover
            this.Location = new Point((Screen.PrimaryScreen.Bounds.Width - this.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2);

            base.OnMove(e);
        }


        private void jTxtNumeroT_TextChanged(object sender, EventArgs e)
        {
            string input = jTxtNumeroT.Text.Replace(" ", "").Trim();

            if (input.Length == 16)
            {
                string last4Digits = input.Substring(12);
                jTxtNumeroT.Text = "**** **** **** " + last4Digits;
                jTxtNomTitular.Focus(); // Dar el enfoque al campo de texto jTxtNomTitular
            }
        }

        private void jTxtNumeroT_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificar si el carácter ingresado es un número o la tecla de retroceso
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                // Ignorar el carácter ingresado si no es un número ni la tecla de retroceso
                e.Handled = true;
            }

            // Verificar si ya se han ingresado 16 caracteres
            if (jTxtNumeroT.Text.Replace(" ", "").Length >= 16 && e.KeyChar != '\b')
            {
                // Ignorar el carácter ingresado si ya hay 16 caracteres
                e.Handled = true;
            }
        }

        private void jTxtAño_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorar el carácter ingresado
            }
        }

        private void jTxtMes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorar el carácter ingresado
            }
        }

        private void jTxtAño_TextChanged(object sender, EventArgs e)
        {
            if (jTxtAño.Text.Length > 4)
            {
                jTxtAño.Text = jTxtAño.Text.Substring(0, 4);
            }
        }

        private void jTxtMes_TextChanged(object sender, EventArgs e)
        {
            if (jTxtMes.Text.Length > 2)
            {
                jTxtMes.Text = jTxtMes.Text.Substring(0, 2);
            }
        }

        private void jTxtNomTitular_TextChanged(object sender, EventArgs e)
        {
            // Obtener el texto ingresado en el TextBox jTxtNomTitular
            string texto = jTxtNomTitular.Text;

            // Realizar las acciones necesarias con el texto ingresado
            // Por ejemplo, validar la longitud máxima del nombre titular
            if (texto.Length > 25)
            {
                // Truncar el texto a 25 caracteres
                jTxtNomTitular.Text = texto.Substring(0, 25);
            }
        }

        private void jTxtCVV_TextChanged(object sender, EventArgs e)
        {
            // Obtener el texto ingresado en el TextBox jTxtCVV
            string texto = jTxtCVV.Text;

            // Validar que el texto solo contenga números y tenga una longitud máxima de 3 caracteres
            if (!string.IsNullOrEmpty(texto) && texto.All(char.IsDigit) && texto.Length > 3)
            {
                // Truncar el texto a 3 caracteres
                jTxtCVV.Text = texto.Substring(0, 3);
            }
        }

        private void btnCancelarT_Click(object sender, EventArgs e)
        {
            // Agrega el código para cancelar el registro de la tarjeta
        }

        private void btnGuardarT_Click(object sender, EventArgs e)
        {
            string numero = jTxtNumeroT.Text.Replace(" ", "").Trim();

            if (numero.Length != 16)
            {
                MessageBox.Show("Número de tarjeta incorrecto. Debe contener exactamente 16 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                jTxtNumeroT.Focus();
                return;
            }

            string nombreTitular = jTxtNomTitular.Text;
            int año = Convert.ToInt32(jTxtAño.Text);
            int mes = Convert.ToInt32(jTxtMes.Text);
            string cvv = jTxtCVV.Text;

            try
            {
                // Guardar la tarjeta en la base de datos utilizando el email del usuario
                CConexion conexion = new CConexion();
                conexion.GuardarTarjeta(numero, nombreTitular, año, mes, cvv, EmailUsuario);

                // Mostrar mensaje de confirmación
                MessageBox.Show("La tarjeta se ha guardado correctamente.", "Tarjeta Guardada", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Cerrar la instancia actual del formulario MisTarjetasForm si está abierta
                foreach (Form form in Application.OpenForms)
                {
                    if (form is MisTarjetasForm)
                    {
                        form.Close();
                        break;
                    }
                }

                // Mostrar el formulario MisTarjetasForm como cuadro de diálogo modal
                MisTarjetasForm misTarjetasForm = new MisTarjetasForm(EmailUsuario); // Pasar el valor de EmailUsuario al constructor
                misTarjetasForm.StartPosition = FormStartPosition.CenterScreen;
                misTarjetasForm.ShowDialog();

                // Cerrar el formulario actual
                this.Close();
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error
                MessageBox.Show("Error al guardar la tarjeta: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnCancelarT_Click_1(object sender, EventArgs e)
        {
            // Cerrar el formulario MiPerfilForm
            this.Close();

            
        }

    }
}


