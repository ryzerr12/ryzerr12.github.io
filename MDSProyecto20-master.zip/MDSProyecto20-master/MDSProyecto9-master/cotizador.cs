﻿using MDSProyecto.Clases;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class Cotizador : Form
    {
        static string servidor = "localhost";
        static string bd = "pp";
        static string usuario = "prueba";
        static string password = "12345";
        static string puerto = "1433";

        string connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

        public Cotizador()
        {
            InitializeComponent();
            
            // Centrar el formulario en la pantalla
            this.StartPosition = FormStartPosition.CenterScreen;

            // Deshabilitar botones de minimizar y maximizar
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Deshabilitar el control box (botones de cerrar y barra de título)
            this.ControlBox = false;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            // Deshabilitar el ajuste del tamaño del formulario con el mouse
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            //conexion = new SqlConnection(connectionString);
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonGuardar_Click_1(object sender, EventArgs e)
        {
            try
            {
                string producto = Producto.Text;
                decimal pesoKilogramos = decimal.Parse(PesoKilogramos.Text); // Convertir a decimal
                decimal valorUni = decimal.Parse(ValorUni.Text); // Convertir a decimal
                int cantidad = int.Parse(Cantidad.Text); // Convertir a entero

                // Verificar si el PesoKilogramos está dentro del rango válido
                if (pesoKilogramos >= 50 && pesoKilogramos <= 1400)
                {
                    string consultaInsertar = "INSERT INTO Cotizar (Producto, PesoKilogramos, ValorUni, Cantidad) " +
                                              "VALUES (@Producto, @PesoKilogramos, @ValorUni, @Cantidad)";

                    using (SqlConnection conexionGuardar = new SqlConnection(connectionString))
                    {
                        using (SqlCommand comandoInsertar = new SqlCommand(consultaInsertar, conexionGuardar))
                        {
                            comandoInsertar.Parameters.AddWithValue("@Producto", producto);
                            comandoInsertar.Parameters.AddWithValue("@PesoKilogramos", pesoKilogramos);
                            comandoInsertar.Parameters.AddWithValue("@ValorUni", valorUni);
                            comandoInsertar.Parameters.AddWithValue("@Cantidad", cantidad);

                            conexionGuardar.Open();
                            comandoInsertar.ExecuteNonQuery();
                            conexionGuardar.Close();

                            MessageBox.Show("Datos guardados exitosamente en la base de datos.");

                            // Llamar al formulario "CostoCoti" y pasar los valores convertidos como argumentos
                            CostoCoti costoCotiForm = new CostoCoti(pesoKilogramos, valorUni, cantidad);
                            costoCotiForm.ShowDialog(); // Utiliza ShowDialog para que el formulario se muestre de forma modal
                        }
                    }
                }
                else
                {
                    // Mostrar mensaje de error si PesoKilogramos no cumple los requisitos
                    MessageBox.Show("El servicio está disponible a partir de los 50 kg y la cantidad puede ser cualquier valor.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingresa valores numéricos válidos para PesoKilogramos, ValorUni y Cantidad.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
