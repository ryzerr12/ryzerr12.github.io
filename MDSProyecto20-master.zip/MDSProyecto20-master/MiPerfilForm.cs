﻿using MDSProyecto.Clases;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class MiPerfilForm : Form
    {
        private string numeroIdentificacion;
        private string email;

        public MiPerfilForm(string numeroIdentificacion, string email)
        {
            InitializeComponent();

            this.numeroIdentificacion = numeroIdentificacion;
            this.email = email;

            CargarDatosUsuario();

            // Establecer los TextBox de solo lectura
            txtNumeroIdentificacion.ReadOnly = true;
            txtEmail.ReadOnly = true;

            // Asociar el evento KeyPress al TextBox txtTelefono
            txtTelefono.KeyPress += txtTelefono_KeyPress;

            // Deshabilitar botones de minimizar y maximizar
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Deshabilitar el control box (botones de cerrar y barra de título)
            this.ControlBox = false;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            // Deshabilitar el ajuste del tamaño del formulario con el mouse
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void CargarDatosUsuario()
        {
            CConexion conexion = new CConexion();
            conexion.EstablecerConexion();

            string nombre = conexion.ObtenerNombreUsuario(email);
            string apellido = conexion.ObtenerApellidoUsuario(email);
            string numeroIdentificacion = conexion.ObtenerNumeroIdentificacionUsuario(email);
            string telefono = conexion.ObtenerTelefonoUsuario(email); // Obtener el teléfono del usuario
            string direccion = conexion.ObtenerDireccionUsuario(email); // Obtener la dirección del usuario


            txtNombre.Text = nombre;
            txtApellido.Text = apellido;
            txtNumeroIdentificacion.Text = numeroIdentificacion;
            txtEmail.Text = email; // Asignar el valor del email al TextBox "txtEmail"
            txtTelefono.Text = telefono; // Asignar el valor del teléfono al TextBox "txtTelefono"
            txtDireccion.Text = direccion; // Asignar el valor de la dirección al TextBox "txtDireccion"
        }


        private void button1_Click(object sender, EventArgs e)
        {
            // Código del botón
        }

        private void txtNumeroIdentificacion_TextChanged(object sender, EventArgs e)
        {
            // Código del evento
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {
            // Código del evento
        }

        private void txtApellido_TextChanged(object sender, EventArgs e)
        {
            // Código del evento
        }

        // Evento Click del botón "btnActualizar"
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            string telefono = txtTelefono.Text;
            string direccion = txtDireccion.Text; // Obtener el valor del TextBox "txtDireccion"

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(telefono))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            CConexion conexion = new CConexion();
            SqlConnection sqlConnection = conexion.EstablecerConexion(); // Establecer conexión con la base de datos

            if (sqlConnection.State == ConnectionState.Open)
            {
                // Llamar al método de la clase de conexión para actualizar la información del usuario
                conexion.ActualizarInformacionUsuario(email, nombre, apellido, telefono, direccion); // Agregar el valor de la dirección

                MessageBox.Show("Información actualizada correctamente.");

                sqlConnection.Close(); // Cerrar la conexión después de usarla
                                       // Cerrar el formulario
                this.Close();
            }
            else
            {
                MessageBox.Show("No se pudo establecer la conexión a la base de datos", "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números y teclas de control (por ejemplo, Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Cancelar el evento de tecla
            }

            // Limitar el texto a 10 caracteres (10 números)
            if (txtTelefono.Text.Length >= 10 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Cancelar el evento de tecla
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
