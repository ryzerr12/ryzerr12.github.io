﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class PendienteForm : Form
    {
 
        private string userEmail;
        private string connectionString;
        
        private static PendienteForm instance;

        private List<DataGridViewRow> datosPendientes = new List<DataGridViewRow>();

        // Agregar una variable para controlar el formato
        private bool isFormatting = false;


        public PendienteForm(string userEmail)
        {
            this.userEmail = userEmail;
            
            InitializeComponent();
            

            string servidor = "localhost";
            string bd = "pp";
            string usuario = "prueba";
            string password = "12345";
            string puerto = "1433";

            connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";

            LoadData();
            CustomizeDataGridView();
            // Suscribir al evento DataBindingComplete del DataGridView
            dataGridViewServicios.CellFormatting += dataGridViewServicios_CellFormatting;
            dataGridViewServicios.CellFormatting += dataGridViewServicios_CellFormatting;

            // Definir el tamaño del formulario
            this.Size = new System.Drawing.Size(860, 350); // Ancho:  Alto: 

            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Habilitar la selección múltiple en el DataGridView
            dataGridViewServicios.MultiSelect = true;

            if (instance != null && !instance.IsDisposed)
            {
                instance.Focus();
                this.Close(); // Cerrar el formulario actual
                return;
            }

            instance = this;
            
        }
        private void dataGridViewServicios_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridViewServicios.Rows)
            {
                // Formatear el valor de la columna "PesoKg"
                if (row.Cells["PesoKg"].Value != null && row.Cells["PesoKg"].Value is decimal pesoKg)
                {
                    row.Cells["PesoKg"].Value = pesoKg.ToString("N2");
                }

                // Formatear el valor de la columna "ValorUni"
                if (row.Cells["ValorUni"].Value != null && row.Cells["ValorUni"].Value is decimal valorUni)
                {
                    row.Cells["ValorUni"].Value = valorUni.ToString("N2");
                }
            }
        }

        private void dataGridViewServicios_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // Verificar si la celda contiene un valor decimal y está en una columna que queremos formatear
            if (e.Value != null && e.Value is decimal && e.ColumnIndex >= 0)
            {
                // Formatear el valor reemplazando el punto por la coma
                e.Value = e.Value.ToString().Replace(".", ",");
                e.FormattingApplied = true;
            }
        }




        private void PendienteForm_Load(object sender, EventArgs e)
        {
            
        }



        private void LoadData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Consulta SQL para seleccionar solo las columnas deseadas y en el orden requerido
                    string query = "SELECT [ID], [ProEnviar], [PesoKg], [ValorUni], [Cantidad], [Fecha], [Hora], [Ancho], [Alto], [Largo] FROM [dbo].[AgendaServicio] WHERE UsuarioEmail = @UsuarioEmail";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Agregar el parámetro del correo electrónico del usuario
                        command.Parameters.AddWithValue("@UsuarioEmail", userEmail);

                        // Crear un adaptador de datos para leer los resultados de la consulta
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            // Crear un DataSet para contener los datos
                            DataSet dataSet = new DataSet();

                            // Llenar el DataSet con los resultados de la consulta
                            adapter.Fill(dataSet);

                            // Establecer la cultura en CultureInfo.InvariantCulture para los valores decimales
                            dataSet.Locale = CultureInfo.InvariantCulture;

                            // Asignar el DataTable del DataSet como origen de datos del DataGridView
                            dataGridViewServicios.DataSource = dataSet.Tables[0];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void CustomizeDataGridView()
        {
            // Establecer el modo de ajuste de columnas a None para que no se ajusten automáticamente
            dataGridViewServicios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            // Ajustar el ancho de cada columna individualmente (puedes ajustar los valores según tus necesidades)
            dataGridViewServicios.Columns["ID"].Width = 30;
            dataGridViewServicios.Columns["ProEnviar"].Width = 240;
            dataGridViewServicios.Columns["PesoKg"].Width = 60;
            dataGridViewServicios.Columns["ValorUni"].Width = 60;
            dataGridViewServicios.Columns["Cantidad"].Width = 60;
            dataGridViewServicios.Columns["Fecha"].Width = 60;
            dataGridViewServicios.Columns["Hora"].Width = 60;
            dataGridViewServicios.Columns["Ancho"].Width = 60;
            dataGridViewServicios.Columns["Alto"].Width = 55;
            dataGridViewServicios.Columns["Largo"].Width = 40;

            // Establecer el formato para las columnas que contienen valores decimales
            dataGridViewServicios.Columns["PesoKg"].DefaultCellStyle.Format = "0.00";
            dataGridViewServicios.Columns["ValorUni"].DefaultCellStyle.Format = "0.00";
            dataGridViewServicios.Columns["Ancho"].DefaultCellStyle.Format = "0.00";
            dataGridViewServicios.Columns["Alto"].DefaultCellStyle.Format = "0.00";
            dataGridViewServicios.Columns["Largo"].DefaultCellStyle.Format = "0.00";


            // Ocultar los títulos de las columnas
            dataGridViewServicios.ColumnHeadersVisible = true;

            // Finalmente, desactivar la ordenación de columnas haciendo clic en los encabezados
            foreach (DataGridViewColumn column in dataGridViewServicios.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormularioIniciarPro_ProcesoFinalizado(object sender, EventArgs e)
        {
           
            ((Form)sender).Close();
        }

        public event EventHandler<List<DataGridViewRow>> DatosPendientesEnviados;

        private void EnviarDatosPendientes()
        {
            DatosPendientesEnviados?.Invoke(this, datosPendientes);
        }



    }
}
