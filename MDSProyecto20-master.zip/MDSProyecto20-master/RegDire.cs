﻿using MDSProyecto.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDSProyecto
{
    public partial class RegDire : Form
    {
        private bool esQuito = false;


        private CConexion conexion;
        static string servidor = "localhost";
        static string bd = "pp";
        static string usuario = "prueba";
        static string password = "12345";
        static string puerto = "1433";

        string connectionString = $"Data Source={servidor},{puerto};Initial Catalog={bd};User ID={usuario};Password={password};";
        public RegDire(CConexion cConexion)
        {
            InitializeComponent();
            conexion = cConexion;

            // Establecer propiedades del formulario
            this.StartPosition = FormStartPosition.CenterScreen; // Aparecer en el centro de la pantalla
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Evitar que se pueda cambiar el tamaño
            this.MaximizeBox = false; // Deshabilitar el botón de maximizar
            this.MinimizeBox = false; // Deshabilitar el botón de minimizar
            this.ControlBox = false; // Ocultar la barra de título (los botones de cerrar, minimizar y maximizar)

            
            this.TxtCiuda.Click += new System.EventHandler(this.TxtCiuda_Click);
            this.TxtCiuda.Leave += new System.EventHandler(this.TxtCiuda_Leave);
            this.txtCalle.Click += new System.EventHandler(this.txtCalle_Click);
            this.txtCalle.Leave += new System.EventHandler(this.txtCalle_Leave);
            this.txtInter.Click += new System.EventHandler(this.txtInter_Click);
            this.txtInter.Leave += new System.EventHandler(this.txtInter_Leave);
            this.txtRefe.Click += new System.EventHandler(this.txtRefe_Click);
            this.txtRefe.Leave += new System.EventHandler(this.txtRefe_Leave);
            this.txtCasa.Click += new System.EventHandler(this.txtCasa_Click);
            this.txtCasa.Leave += new System.EventHandler(this.txtCasa_Leave);

            // Asociar los eventos KeyPress y TextChanged al TextBox TxtCiuda
            TxtCiuda.KeyPress += TxtCiuda_KeyPress;

            // Ocultar el título del formulario
            this.Text = string.Empty;

            
        }

        private void TxtCiuda_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir solo letras y teclas de control
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Cancelar el evento de tecla
            }
        }


        private void btnRegDire_Click(object sender, EventArgs e)
        {
            try
            {
                // Leer los valores ingresados en los TextBox
                string ciudad = TxtCiuda.Text;
                string calle = txtCalle.Text;
                string interseccion = txtInter.Text;
                string referencia = txtRefe.Text;
                string casa = txtCasa.Text;

                // Validar que el valor ingresado sea "quito" o "Quito"
                if (ciudad.ToLower() != "quito")
                {
                    MessageBox.Show("Querido cliente, por el momento, realizamos entregas únicamente en Quito-Carapungo. No te desanimes, estamos trabajando arduamente para expandir nuestros servicios a más ciudades. ¡Permanece atento, pronto estaremos cerca de ti!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Cadena de consulta SQL para insertar los datos en la tabla Dire
                string query = "INSERT INTO dbo.Dire (Ciudad, Calle, Interseccion, Referencia, Casa, UsuarioEmail) VALUES (@Ciudad, @Calle, @Interseccion, @Referencia, @Casa, @UsuarioEmail)";

                // Crear y abrir la conexión a la base de datos
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Crear el comando SQL y agregar los parámetros
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ciudad", ciudad);
                        command.Parameters.AddWithValue("@Calle", calle);
                        command.Parameters.AddWithValue("@Interseccion", interseccion);
                        command.Parameters.AddWithValue("@Referencia", referencia);
                        command.Parameters.AddWithValue("@Casa", casa);
                        command.Parameters.AddWithValue("@UsuarioEmail", Form2.EmailUsuario); // Aquí se pasa el correo electrónico del usuario desde Form2

                        // Ejecutar la consulta
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Datos agregados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Limpiar los TextBox después de insertar los datos
                            LimpiarTextBox();

                            // Cerrar el formulario actual (RegDire.cs)
                            this.Close();

                            // Abrir el formulario DireccionesForm.cs
                            DireccionesForm direccionesForm = new DireccionesForm();
                            direccionesForm.StartPosition = FormStartPosition.CenterScreen; // Establecer el inicio del formulario en el centro de la pantalla
                            direccionesForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo agregar los datos a la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void LimpiarTextBox()
        {
            TxtCiuda.Text = string.Empty;
            txtCalle.Text = string.Empty;
            txtInter.Text = string.Empty;
            txtRefe.Text = string.Empty;
            txtCasa.Text = string.Empty;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            // Cerrar el formulario actual (RegDire.cs)
            this.Close();

            // Abrir el formulario DireccionesForm.cs
            DireccionesForm direccionesForm = new DireccionesForm();
            direccionesForm.StartPosition = FormStartPosition.CenterScreen; // Establecer el inicio del formulario en el centro de la pantalla
            direccionesForm.Show();
        }

        private void RegDire_Load(object sender, EventArgs e)
        {
            TxtCiuda.Text = "Ingresar...";
            TxtCiuda.ForeColor = Color.Gray;

            txtCalle.Text = "Ingresar...";
            txtCalle.ForeColor = Color.Gray;

            txtInter.Text = "Ingresar...";
            txtInter.ForeColor = Color.Gray;

            txtRefe.Text = "Ingresar...";
            txtRefe.ForeColor = Color.Gray;

            txtCasa.Text = "Ingresar...";
            txtCasa.ForeColor = Color.Gray;

            
        }

        private void TxtCiuda_Click(object sender, EventArgs e)
        {
            if (TxtCiuda.Text == "Ingresar...")
            {
                TxtCiuda.Text = "";
                TxtCiuda.ForeColor = Color.Black;
            }
        }

        private void TxtCiuda_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TxtCiuda.Text))
            {
                TxtCiuda.Text = "Ingresar...";
                TxtCiuda.ForeColor = Color.Gray;
            }
        }
        private void txtRefe_Click(object sender, EventArgs e)
        {
            if (txtRefe.Text == "Ingresar...")
            {
                txtRefe.Text = "";
                txtRefe.ForeColor = Color.Black;
            }
        }

        private void txtRefe_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtRefe.Text))
            {
                txtRefe.Text = "Ingresar...";
                txtRefe.ForeColor = Color.Gray;
            }
        }
        private void txtCalle_Click(object sender, EventArgs e)
        {
            if (txtCalle.Text == "Ingresar...")
            {
                txtCalle.Text = "";
                txtCalle.ForeColor = Color.Black;
            }
        }

        private void txtCalle_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCalle.Text))
            {
                txtCalle.Text = "Ingresar...";
                txtCalle.ForeColor = Color.Gray;
            }
        }

        private void txtInter_Click(object sender, EventArgs e)
        {
            if (txtInter.Text == "Ingresar...")
            {
                txtInter.Text = "";
                txtInter.ForeColor = Color.Black;
            }
        }

        private void txtInter_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtInter.Text))
            {
                txtInter.Text = "Ingresar...";
                txtInter.ForeColor = Color.Gray;
            }
        }
        private void txtCasa_Click(object sender, EventArgs e)
        {
            if (txtCasa.Text == "Ingresar...")
            {
                txtCasa.Text = "";
                txtCasa.ForeColor = Color.Black;
            }
        }

        private void txtCasa_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCasa.Text))
            {
                txtCasa.Text = "Ingresar...";
                txtCasa.ForeColor = Color.Gray;
            }
        }

    }
}


