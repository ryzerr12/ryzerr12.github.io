﻿namespace MDSProyecto
{
    partial class RegistrarTarjetaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jTxtNumeroT = new System.Windows.Forms.TextBox();
            this.jTxtNomTitular = new System.Windows.Forms.TextBox();
            this.jTxtAño = new System.Windows.Forms.TextBox();
            this.jTxtMes = new System.Windows.Forms.TextBox();
            this.jTxtCVV = new System.Windows.Forms.TextBox();
            this.btnCancelarT = new System.Windows.Forms.Button();
            this.btnGuardarT = new System.Windows.Forms.Button();
            this.userLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBoxT = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxT)).BeginInit();
            this.SuspendLayout();
            // 
            // jTxtNumeroT
            // 
            this.jTxtNumeroT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jTxtNumeroT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jTxtNumeroT.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jTxtNumeroT.Location = new System.Drawing.Point(214, 332);
            this.jTxtNumeroT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jTxtNumeroT.Name = "jTxtNumeroT";
            this.jTxtNumeroT.Size = new System.Drawing.Size(230, 32);
            this.jTxtNumeroT.TabIndex = 3;
            this.jTxtNumeroT.TextChanged += new System.EventHandler(this.jTxtNumeroT_TextChanged);
            // 
            // jTxtNomTitular
            // 
            this.jTxtNomTitular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jTxtNomTitular.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jTxtNomTitular.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jTxtNomTitular.Location = new System.Drawing.Point(218, 412);
            this.jTxtNomTitular.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jTxtNomTitular.Name = "jTxtNomTitular";
            this.jTxtNomTitular.Size = new System.Drawing.Size(226, 32);
            this.jTxtNomTitular.TabIndex = 4;
            // 
            // jTxtAño
            // 
            this.jTxtAño.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jTxtAño.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jTxtAño.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jTxtAño.Location = new System.Drawing.Point(182, 503);
            this.jTxtAño.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jTxtAño.Name = "jTxtAño";
            this.jTxtAño.Size = new System.Drawing.Size(128, 32);
            this.jTxtAño.TabIndex = 5;
            this.jTxtAño.TextChanged += new System.EventHandler(this.jTxtAño_TextChanged);
            // 
            // jTxtMes
            // 
            this.jTxtMes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jTxtMes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jTxtMes.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jTxtMes.Location = new System.Drawing.Point(393, 503);
            this.jTxtMes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jTxtMes.Name = "jTxtMes";
            this.jTxtMes.Size = new System.Drawing.Size(128, 32);
            this.jTxtMes.TabIndex = 6;
            this.jTxtMes.TextChanged += new System.EventHandler(this.jTxtMes_TextChanged);
            // 
            // jTxtCVV
            // 
            this.jTxtCVV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(235)))), ((int)(((byte)(100)))));
            this.jTxtCVV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jTxtCVV.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jTxtCVV.Location = new System.Drawing.Point(210, 591);
            this.jTxtCVV.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jTxtCVV.Name = "jTxtCVV";
            this.jTxtCVV.Size = new System.Drawing.Size(231, 32);
            this.jTxtCVV.TabIndex = 7;
            // 
            // btnCancelarT
            // 
            this.btnCancelarT.BackColor = System.Drawing.Color.Black;
            this.btnCancelarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarT.ForeColor = System.Drawing.Color.Gold;
            this.btnCancelarT.Location = new System.Drawing.Point(162, 711);
            this.btnCancelarT.Name = "btnCancelarT";
            this.btnCancelarT.Size = new System.Drawing.Size(172, 42);
            this.btnCancelarT.TabIndex = 8;
            this.btnCancelarT.Text = "Cancelar";
            this.btnCancelarT.UseVisualStyleBackColor = false;
            this.btnCancelarT.Click += new System.EventHandler(this.btnCancelarT_Click_1);
            // 
            // btnGuardarT
            // 
            this.btnGuardarT.BackColor = System.Drawing.Color.Black;
            this.btnGuardarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarT.ForeColor = System.Drawing.Color.Gold;
            this.btnGuardarT.Location = new System.Drawing.Point(380, 711);
            this.btnGuardarT.Name = "btnGuardarT";
            this.btnGuardarT.Size = new System.Drawing.Size(172, 42);
            this.btnGuardarT.TabIndex = 9;
            this.btnGuardarT.Text = "Guardar ";
            this.btnGuardarT.UseVisualStyleBackColor = false;
            this.btnGuardarT.Click += new System.EventHandler(this.btnGuardarT_Click);
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.userLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userLabel.Location = new System.Drawing.Point(177, 282);
            this.userLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(132, 25);
            this.userLabel.TabIndex = 11;
            this.userLabel.Text = "Numero Tarjeta";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(388, 458);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 25);
            this.label1.TabIndex = 12;
            this.label1.Text = "Mes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(177, 458);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 25);
            this.label2.TabIndex = 13;
            this.label2.Text = "Año";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(206, 555);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 25);
            this.label3.TabIndex = 14;
            this.label3.Text = "CVV";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(182, 374);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "Nombres Titular";
            // 
            // pictureBoxT
            // 
            this.pictureBoxT.Image = global::MDSProyecto.Properties.Resources.regTarjeTtt;
            this.pictureBoxT.Location = new System.Drawing.Point(2, 2);
            this.pictureBoxT.Name = "pictureBoxT";
            this.pictureBoxT.Size = new System.Drawing.Size(660, 805);
            this.pictureBoxT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxT.TabIndex = 16;
            this.pictureBoxT.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(315, 284);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 22);
            this.label5.TabIndex = 17;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(324, 377);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 22);
            this.label6.TabIndex = 18;
            this.label6.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(224, 461);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 22);
            this.label7.TabIndex = 19;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(431, 461);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 22);
            this.label8.TabIndex = 20;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(224)))), ((int)(((byte)(0)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(258, 558);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 22);
            this.label9.TabIndex = 21;
            this.label9.Text = "*";
            // 
            // RegistrarTarjetaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 803);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnGuardarT);
            this.Controls.Add(this.btnCancelarT);
            this.Controls.Add(this.jTxtCVV);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.jTxtMes);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jTxtAño);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.jTxtNomTitular);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.jTxtNumeroT);
            this.Controls.Add(this.userLabel);
            this.Controls.Add(this.pictureBoxT);
            this.Name = "RegistrarTarjetaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistarTarjeta";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox jTxtNumeroT;
        private System.Windows.Forms.TextBox jTxtNomTitular;
        private System.Windows.Forms.TextBox jTxtAño;
        private System.Windows.Forms.TextBox jTxtMes;
        private System.Windows.Forms.TextBox jTxtCVV;
        private System.Windows.Forms.Button btnCancelarT;
        private System.Windows.Forms.Button btnGuardarT;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBoxT;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}